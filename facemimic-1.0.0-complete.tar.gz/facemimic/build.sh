#!/bin/bash
#
# FaceMimic Stealth Build Script
# Compiles the server and client binaries with optimizations for size and stealth.
#
# Usage: ./build.sh [server|client|all]
#
# Features:
#   - Stripped binaries for minimal size and no debug symbols
#   - Static linking for portability
#   - Renamed binary to mimic system process
#   - Stripped build ID for anonymity
#

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Logging functions
log_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

log_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Binary name (looks like a kernel worker process)
SERVER_BINARY="kworker-d"
CLIENT_BINARY="kworker-u"

# Build mode
BUILD_MODE="${1:-all}"

# Go build flags for maximum stealth
# -s: Omit the symbol table and debug information
# -w: Omit the DWARF symbol table
# -buildid=: Empty the build ID (prevents binary fingerprinting)
# -linkmode=external: Use external linker
# -extldflags '-static': Static linking for portability
GO_LDFLAGS="-s -w -buildid= "
GO_LDFLAGS_STATIC="-s -w -buildid= -linkmode=external -extldflags '-static'"

# Check Go installation
if ! command -v go &> /dev/null; then
    log_error "Go is not installed. Please install Go 1.22 or later."
    exit 1
fi

GO_VERSION=$(go version | awk '{print $3}' | sed 's/go//')
log_info "Using Go version: $GO_VERSION"

# Create build directory
BUILD_DIR="./build"
mkdir -p "$BUILD_DIR"

# Function to build server
build_server() {
    log_info "Building server binary..."

    # Build with static linking for maximum portability
    cd server

    # Try static build first, fall back to dynamic if static fails
    if go build -ldflags "$GO_LDFLAGS_STATIC" -o "../$BUILD_DIR/$SERVER_BINARY" . 2>/dev/null; then
        log_info "Server built with static linking"
    else
        log_warn "Static linking failed, using dynamic linking..."
        go build -ldflags "$GO_LDFLAGS" -o "../$BUILD_DIR/$SERVER_BINARY" .
    fi

    cd ..

    # Strip all symbols
    strip --strip-all "$BUILD_DIR/$SERVER_BINARY" 2>/dev/null || true

    # Set capabilities for binding to privileged ports
    if command -v setcap &> /dev/null; then
        setcap CAP_NET_BIND_SERVICE=+ep "$BUILD_DIR/$SERVER_BINARY"
        log_info "Set CAP_NET_BIND_SERVICE capability"
    fi

    # Get binary info
    BINARY_SIZE=$(du -h "$BUILD_DIR/$SERVER_BINARY" | cut -f1)
    log_info "Server binary: $BUILD_DIR/$SERVER_BINARY ($BINARY_SIZE)"
}

# Function to build client
build_client() {
    log_info "Building client binary..."

    cd client

    # Build with static linking for maximum portability
    if go build -ldflags "$GO_LDFLAGS_STATIC" -o "../$BUILD_DIR/$CLIENT_BINARY" . 2>/dev/null; then
        log_info "Client built with static linking"
    else
        log_warn "Static linking failed, using dynamic linking..."
        go build -ldflags "$GO_LDFLAGS" -o "../$BUILD_DIR/$CLIENT_BINARY" .
    fi

    cd ..

    # Strip all symbols
    strip --strip-all "$BUILD_DIR/$CLIENT_BINARY" 2>/dev/null || true

    # Get binary info
    BINARY_SIZE=$(du -h "$BUILD_DIR/$CLIENT_BINARY" | cut -f1)
    log_info "Client binary: $BUILD_DIR/$CLIENT_BINARY ($BINARY_SIZE)"
}

# Function to build for multiple platforms
build_cross_compile() {
    log_info "Cross-compiling for multiple platforms..."

    PLATFORMS=(
        "linux/amd64"
        "linux/arm64"
        "darwin/amd64"
        "darwin/arm64"
        "windows/amd64"
    )

    for PLATFORM in "${PLATFORMS[@]}"; do
        IFS='/' read -r GOOS GOARCH <<< "$PLATFORM"

        log_info "Building for $GOOS/$GOARCH..."

        OUTPUT_NAME="${SERVER_BINARY}-${GOOS}-${GOARCH}"

        if [ "$GOOS" = "windows" ]; then
            OUTPUT_NAME="${OUTPUT_NAME}.exe"
        fi

        GOOS=$GOOS GOARCH=$GOARCH go build -ldflags "$GO_LDFLAGS" -o "$BUILD_DIR/$OUTPUT_NAME" ./server

        # Strip (platform-dependent)
        if [ "$GOOS" = "linux" ] || [ "$GOOS" = "darwin" ]; then
            strip --strip-all "$BUILD_DIR/$OUTPUT_NAME" 2>/dev/null || true
        fi

        BINARY_SIZE=$(du -h "$BUILD_DIR/$OUTPUT_NAME" | cut -f1)
        log_info "Built: $BUILD_DIR/$OUTPUT_NAME ($BINARY_SIZE)"
    done
}

# Function to verify build
verify_build() {
    log_info "Verifying binaries..."

    # Check server binary
    if [ -f "$BUILD_DIR/$SERVER_BINARY" ]; then
        log_info "Server binary verification:"
        file "$BUILD_DIR/$SERVER_BINARY"
        echo "  Size: $(du -h "$BUILD_DIR/$SERVER_BINARY" | cut -f1)"
        echo "  MD5:  $(md5sum "$BUILD_DIR/$SERVER_BINARY" | cut -d' ' -f1)"
        echo "  SHA256: $(sha256sum "$BUILD_DIR/$SERVER_BINARY" | cut -d' ' -f1)"
        echo ""

        # Check for debug symbols
        if file "$BUILD_DIR/$SERVER_BINARY" | grep -q "stripped"; then
            log_info "Server binary is properly stripped"
        else
            log_warn "Server binary may still contain debug symbols"
        fi
    fi

    # Check client binary
    if [ -f "$BUILD_DIR/$CLIENT_BINARY" ]; then
        log_info "Client binary verification:"
        file "$BUILD_DIR/$CLIENT_BINARY"
        echo "  Size: $(du -h "$BUILD_DIR/$CLIENT_BINARY" | cut -f1)"
        echo "  MD5:  $(md5sum "$BUILD_DIR/$CLIENT_BINARY" | cut -d' ' -f1)"
        echo "  SHA256: $(sha256sum "$BUILD_DIR/$CLIENT_BINARY" | cut -d' ' -f1)"
        echo ""

        # Check for debug symbols
        if file "$BUILD_DIR/$CLIENT_BINARY" | grep -q "stripped"; then
            log_info "Client binary is properly stripped"
        else
            log_warn "Client binary may still contain debug symbols"
        fi
    fi
}

# Function to create checksums
create_checksums() {
    log_info "Creating checksums..."

    cd "$BUILD_DIR"

    # Create checksums for all binaries
    sha256sum * > checksums.sha256 2>/dev/null || true
    md5sum * > checksums.md5 2>/dev/null || true

    cd ..

    log_info "Checksums created in $BUILD_DIR/"
}

# Main build logic
log_info "Starting FaceMimic build process..."
echo ""

case "$BUILD_MODE" in
    server)
        build_server
        ;;
    client)
        build_client
        ;;
    all)
        build_server
        build_client
        ;;
    cross)
        build_cross_compile
        ;;
    *)
        log_error "Unknown build mode: $BUILD_MODE"
        echo "Usage: $0 [server|client|all|cross]"
        exit 1
        ;;
esac

# Verify and create checksums
verify_build
create_checksums

echo ""
log_info "Build complete!"
echo ""
echo "Binaries available in: $BUILD_DIR/"
ls -la "$BUILD_DIR/"
