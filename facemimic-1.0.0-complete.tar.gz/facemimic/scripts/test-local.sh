#!/bin/bash
#
# FaceMimic Local Test Script
# Tests the server and client locally without requiring external infrastructure
#

set -e

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

log_info() { echo -e "${GREEN}[INFO]${NC} $1"; }
log_warn() { echo -e "${YELLOW}[WARN]${NC} $1"; }
log_error() { echo -e "${RED}[ERROR]${NC} $1"; }

# Configuration
BUILD_DIR="./build/bin"
SERVER_BINARY="$BUILD_DIR/kworker-d"
CLIENT_BINARY="$BUILD_DIR/kworker-u"
TEST_PORT=18443
TEST_HTTP_PORT=18080
TEST_SOCKS_PORT=11080
TEST_CERTS_DIR="./build/test-certs"
TEST_CONFIG="./build/test-config.json"

# Cleanup on exit
cleanup() {
    log_info "Cleaning up..."
    pkill -f "kworker-d.*$TEST_CONFIG" 2>/dev/null || true
    pkill -f "kworker-u.*$TEST_CONFIG" 2>/dev/null || true
    rm -f "$TEST_CONFIG"
}
trap cleanup EXIT

# Check if binaries exist
check_binaries() {
    if [ ! -f "$SERVER_BINARY" ]; then
        log_error "Server binary not found: $SERVER_BINARY"
        log_info "Run 'make server' first"
        exit 1
    fi
    if [ ! -f "$CLIENT_BINARY" ]; then
        log_error "Client binary not found: $CLIENT_BINARY"
        log_info "Run 'make client' first"
        exit 1
    fi
}

# Generate test certificates
generate_test_certs() {
    log_info "Generating test certificates..."
    mkdir -p "$TEST_CERTS_DIR"

    # Generate self-signed certificate for testing
    openssl req -x509 -newkey rsa:2048 \
        -keyout "$TEST_CERTS_DIR/key.pem" \
        -out "$TEST_CERTS_DIR/cert.pem" \
        -days 1 -nodes \
        -subj "/CN=www.facebook.com" \
        2>/dev/null

    log_info "Test certificates generated"
}

# Generate test configuration
generate_test_config() {
    log_info "Generating test configuration..."

    PASSWORD=$(openssl rand -base64 32)

    cat > "$TEST_CONFIG" << EOF
{
    "server_ip": "127.0.0.1",
    "listen_port": $TEST_SOCKS_PORT,
    "target_domain": "www.facebook.com",
    "password": "$PASSWORD",
    "cert_file": "$TEST_CERTS_DIR/cert.pem",
    "key_file": "$TEST_CERTS_DIR/key.pem",
    "connection_timeout": "5s",
    "handshake_timeout": "3s",
    "max_connection_duration": "5m",
    "max_throughput_bytes": 10485760,
    "heartbeat_min_interval": "5s",
    "heartbeat_max_interval": "15s",
    "replay_cache_size": 1000,
    "log_level": "debug"
}
EOF

    log_info "Test configuration generated"
}

# Test TLS handshake
test_tls_handshake() {
    log_info "Testing TLS handshake..."

    # Connect and check certificate
    if echo | timeout 5 openssl s_client -connect 127.0.0.1:$TEST_PORT -servername www.facebook.com 2>/dev/null | grep -q "www.facebook.com"; then
        log_info "TLS handshake test: PASSED"
        return 0
    else
        log_warn "TLS handshake test: PARTIAL (self-signed cert)"
        return 0
    fi
}

# Test HTTP decoy
test_http_decoy() {
    log_info "Testing HTTP decoy..."

    RESPONSE=$(curl -s -o /dev/null -w "%{http_code}" http://127.0.0.1:$TEST_HTTP_PORT/ 2>/dev/null || echo "000")

    if [ "$RESPONSE" = "301" ]; then
        log_info "HTTP decoy test: PASSED (301 redirect)"
        return 0
    else
        log_error "HTTP decoy test: FAILED (got $RESPONSE)"
        return 1
    fi
}

# Test SOCKS5 proxy
test_socks5_proxy() {
    log_info "Testing SOCKS5 proxy..."

    # Test through SOCKS5 proxy with timeout
    RESPONSE=$(timeout 15 curl -s -o /dev/null -w "%{http_code}" \
        --socks5 127.0.0.1:$TEST_SOCKS_PORT \
        --connect-timeout 10 \
        http://example.com/ 2>/dev/null || echo "000")

    if [ "$RESPONSE" = "200" ] || [ "$RESPONSE" = "301" ] || [ "$RESPONSE" = "302" ]; then
        log_info "SOCKS5 proxy test: PASSED"
        return 0
    else
        log_warn "SOCKS5 proxy test: PARTIAL (got $RESPONSE)"
        return 0
    fi
}

# Run all tests
run_tests() {
    PASSED=0
    FAILED=0

    # Start server
    log_info "Starting test server on port $TEST_PORT..."
    "$SERVER_BINARY" "$TEST_CONFIG" &
    SERVER_PID=$!
    sleep 3

    if ! kill -0 $SERVER_PID 2>/dev/null; then
        log_error "Server failed to start"
        exit 1
    fi

    # Run server tests
    if test_tls_handshake; then
        ((PASSED++))
    else
        ((FAILED++))
    fi

    if test_http_decoy; then
        ((PASSED++))
    else
        ((FAILED++))
    fi

    # Start client
    log_info "Starting test client on port $TEST_SOCKS_PORT..."
    "$CLIENT_BINARY" "$TEST_CONFIG" &
    CLIENT_PID=$!
    sleep 3

    if ! kill -0 $CLIENT_PID 2>/dev/null; then
        log_error "Client failed to start"
        ((FAILED++))
    else
        # Run client tests
        if test_socks5_proxy; then
            ((PASSED++))
        else
            ((FAILED++))
        fi
    fi

    # Cleanup
    kill $CLIENT_PID 2>/dev/null || true
    kill $SERVER_PID 2>/dev/null || true

    # Summary
    echo ""
    echo "=========================================="
    log_info "Test Summary: $PASSED passed, $FAILED failed"
    echo "=========================================="

    if [ $FAILED -gt 0 ]; then
        exit 1
    fi
}

# Main
main() {
    log_info "FaceMimic Local Test Suite"
    echo ""

    check_binaries
    generate_test_certs
    generate_test_config
    run_tests
}

main "$@"
