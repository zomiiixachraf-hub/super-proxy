#!/bin/bash
#
# Quick Server Info - Print connection details for mobile setup
#

# Colors
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m'

# Get info
IP=$(curl -s ifconfig.me 2>/dev/null || curl -s ip.sb 2>/dev/null || echo "Unknown")
PASS=$(grep -o '"password": "[^"]*"' /opt/facemimic/config.json 2>/dev/null | cut -d'"' -f4 || echo "Not found")
PORT=443

clear
echo ""
echo -e "${CYAN}╔═══════════════════════════════════════════════════════════╗${NC}"
echo -e "${CYAN}║              FaceMimic Connection Details                 ║${NC}"
echo -e "${CYAN}╚═══════════════════════════════════════════════════════════╝${NC}"
echo ""
echo -e "${GREEN}📋 Copy these details to your phone:${NC}"
echo ""
echo -e "   ${YELLOW}Server IP:${NC}     $IP"
echo -e "   ${YELLOW}Port:${NC}         $PORT"  
echo -e "   ${YELLOW}Password:${NC}     $PASS"
echo ""
echo -e "${CYAN}────────────────────────────────────────────────────────────${NC}"
echo ""
echo -e "${GREEN}🔗 Quick Link:${NC}"
echo ""
echo -e "   facemimic://$IP:$PORT?password=$PASS"
echo ""
echo -e "${CYAN}────────────────────────────────────────────────────────────${NC}"
echo ""
echo -e "${GREEN}📱 Mobile Apps:${NC}"
echo ""
echo "   • Clash for Android"
echo "   • SingBox"  
echo "   • Drony"
echo "   • Postern"
echo ""
echo -e "${CYAN}────────────────────────────────────────────────────────────${NC}"
echo ""
echo -e "${GREEN}📂 Config Files Location:${NC}"
echo ""
echo "   /opt/facemimic/client-configs/"
echo ""
echo -e "${CYAN}────────────────────────────────────────────────────────────${NC}"
echo ""
echo -e "${GREEN}🌐 Web Dashboard:${NC}"
echo ""
echo -e "   http://$IP:8080"
echo ""
echo -e "${CYAN}═══════════════════════════════════════════════════════════${NC}"
echo ""
