# FaceMimic Security Guide

## Threat Model

FaceMimic is designed to withstand scrutiny from state-level adversaries with the following capabilities:

### Adversary Capabilities

1. **Deep Packet Inspection (DPI)**
   - TLS fingerprint analysis
   - SNI inspection
   - Traffic pattern analysis
   - Protocol anomaly detection

2. **Active Probing**
   - Automated probe connections
   - Behavioral testing
   - Certificate validation

3. **Machine Learning Traffic Analysis**
   - Statistical traffic classification
   - Timing correlation attacks
   - Volume analysis

4. **Network Infrastructure Control**
   - BGP routing manipulation
   - DNS tampering
   - IP/ASN blacklisting

## Security Features

### 1. TLS Fingerprint Spoofing

The client uses `utls` library to perfectly mimic Chrome's TLS ClientHello:

```
ClientHello Profile: HelloChrome_Auto
- Extension ordering matches Chrome exactly
- GREASE extensions with correct quadratic residue logic
- Proper cipher suite ordering
- Correct ALPN advertisement (h2, http/1.1)
```

### 2. SessionID Steganography

Authentication is hidden within the TLS SessionID field:

```
SessionID = HMAC-SHA256(PreSharedKey, UnixTimestamp)
```

This is invisible to network observers because:
- SessionID is encrypted in TLS 1.3
- Even in TLS 1.2, it appears as random data
- No distinguishable pattern to detect

### 3. Active Probe Defense

When an unauthorized connection is detected:

1. Server peeks the ClientHello
2. Extracts and validates SessionID
3. If invalid, proxies to real target server
4. Probe sees legitimate Facebook response

This makes active probing ineffective.

### 4. Traffic Morphing

All tunnel data is encapsulated as HTTP/2 frames:

- DATA frames for payload
- Random padding (0-255 bytes)
- Periodic PING frames (15-45s intervals)
- WINDOW_UPDATE for flow control simulation

## Security Recommendations

### Server Deployment

1. **ASN Selection**
   ```
   CRITICAL: Host on ASNs that serve Facebook traffic!
   Recommended: AS32934 (Facebook), AS13335 (Cloudflare), AS54113 (Fastly)
   ```

2. **Certificate Management**
   - Use Let's Encrypt for legitimate certificates
   - Enable automatic renewal
   - Monitor certificate expiration

3. **Time Synchronization**
   ```bash
   # Essential for HMAC validation
   apt install chrony
   # Configure to use Facebook NTP
   echo "server time.facebook.com iburst" >> /etc/chrony/chrony.conf
   ```

4. **Network Hardening**
   - Block QUIC (UDP 443) to prevent protocol leakage
   - Use custom SSH port
   - Enable UFW firewall
   - Disable unnecessary services

### Password Security

Generate strong passwords:

```bash
# Generate 32-byte password
openssl rand -base64 32

# Or use the CLI tool
./facemimic-cli -password
```

Password requirements:
- Minimum 32 characters recommended
- Use cryptographically secure random generator
- Never reuse passwords between deployments
- Store securely (encrypted at rest)

### Operational Security

1. **Connection Hygiene**
   - Rotate connections every 30 minutes
   - Limit throughput to 500MB per connection
   - Use randomized heartbeat intervals

2. **Logging Discipline**
   - Avoid logging sensitive information
   - Use log rotation
   - Encrypt log files
   - Regular log cleanup

3. **Monitoring**
   - Monitor for unusual connection patterns
   - Alert on authentication failures
   - Track probe attempts

## Known Limitations

### Traffic Analysis Resistance

While FaceMimic provides strong resistance to traffic analysis, sophisticated adversaries may still detect usage through:

1. **Statistical Analysis**
   - Long-term traffic patterns
   - Connection timing correlations
   - Volume analysis

   Mitigation: Use consistent traffic patterns, avoid burst transfers

2. **Side Channels**
   - DNS leaks (use encrypted DNS)
   - WebRTC leaks (disable in browser)
   - IPv6 leakage (disable or tunnel IPv6)

3. **Endpoint Correlation**
   - Timing correlation between client and destination
   - Packet size matching

   Mitigation: Add random delays, use padding

### Network-Level Detection

1. **IP Blocking**
   - Server IP can be blocked
   - Use multiple servers with load balancing

2. **ASN Filtering**
   - Incorrect ASN selection triggers detection
   - Always use Facebook-associated ASNs

3. **CDN Fingerprinting**
   - Response timing differences
   - Certificate chain differences

## Incident Response

### If Detection is Suspected

1. Immediately rotate server IP
2. Change authentication password
3. Analyze logs for probe patterns
4. Consider switching target domain

### If Server is Compromised

1. Immediately revoke and reissue certificates
2. Rotate all passwords
3. Rebuild server from clean image
4. Audit all access logs
5. Notify affected users

## Security Audit Checklist

- [ ] Server hosted on recommended ASN
- [ ] Valid TLS certificate from trusted CA
- [ ] Strong password (32+ chars, cryptographically random)
- [ ] Time synchronization configured
- [ ] UFW firewall enabled
- [ ] SSH on non-standard port
- [ ] QUIC blocked (UDP 443)
- [ ] Unnecessary services disabled
- [ ] Log rotation configured
- [ ] Monitoring alerts configured
- [ ] Backup and recovery plan tested

## Vulnerability Reporting

If you discover a security vulnerability, please report it responsibly:

1. Do not publicly disclose
2. Provide detailed reproduction steps
3. Allow reasonable time for fix
4. Coordinate disclosure timing

## Security Updates

Regularly update:
- Go runtime
- Dependencies (go mod tidy)
- System packages
- TLS certificates
