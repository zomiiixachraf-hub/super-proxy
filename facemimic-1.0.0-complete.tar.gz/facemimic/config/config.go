// Package config provides configuration management for FaceMimic tunneling protocol.
// It handles loading, validation, and runtime access to operational parameters.
package config

import (
	"encoding/json"
	"fmt"
	"net"
	"os"
	"time"

	"github.com/sirupsen/logrus"
)

/*
CRITICAL SECURITY WARNING - ASN SELECTION:
================================================================================
The operator must host this server on an ASN that legitimately serves Facebook
traffic (e.g., AS32934 - Facebook's own ASN, or major CDNs like:
- AS13335 (Cloudflare)
- AS15133 (Edgecast)
- AS54113 (Fastly)
- AS8075 (Microsoft)

Failure to do so will result in BGP/IP Database heuristics flagging your IP as
suspicious. Advanced adversaries maintain databases of IP-ASN mappings and can
detect anomalies where "Facebook traffic" originates from unrelated networks.

Additionally, ensure your server's IP has clean reputation and is not listed in
any spam/malware databases, as this may trigger secondary heuristics.
================================================================================
*/

// Config holds all operational parameters for the FaceMimic system.
// It is designed to be loaded from a JSON configuration file at startup.
type Config struct {
	// ServerIP is the public IP address or hostname of the FaceMimic server.
	// For client mode, this specifies the remote server to connect to.
	// For server mode, this is used for logging and identification purposes.
	ServerIP string `json:"server_ip"`

	// ListenPort is the port on which the client SOCKS5 proxy listens.
	// Default: 1080
	ListenPort int `json:"listen_port"`

	// TargetDomain is the domain to mimic (e.g., www.facebook.com).
	// This is used for SNI and certificate generation.
	// IMPORTANT: Must match the domain on your TLS certificate.
	TargetDomain string `json:"target_domain"`

	// TargetAddr holds the resolved IP address(es) of the actual target domain.
	// This is used for the "Zero-Latency Fallback" when active probes are detected.
	// The server resolves this once at startup and caches it to minimize latency.
	TargetAddr net.IP `json:"-"`

	// Password is the pre-shared secret used for HMAC-based authentication.
	// It should be a cryptographically strong random string (minimum 32 characters).
	// WARNING: Never transmit this password over the network in plaintext.
	Password string `json:"password"`

	// CertFile is the path to the TLS certificate file (PEM format).
	// Must be a valid certificate for the TargetDomain.
	// Recommended: Use Let's Encrypt via Certbot for legitimate certificates.
	CertFile string `json:"cert_file"`

	// KeyFile is the path to the TLS private key file (PEM format).
	// Must correspond to the CertFile.
	// CRITICAL: Ensure proper file permissions (chmod 600).
	KeyFile string `json:"key_file"`

	// ConnectionTimeout specifies the maximum time to wait for connection establishment.
	// Default: 10 seconds
	ConnectionTimeout time.Duration `json:"connection_timeout"`

	// HandshakeTimeout specifies the maximum time for TLS handshake completion.
	// Default: 5 seconds
	HandshakeTimeout time.Duration `json:"handshake_timeout"`

	// MaxConnectionDuration is the maximum time a single tunnel connection can exist.
	// After this duration, the connection is rotated to mimic user behavior.
	// Default: 30 minutes
	MaxConnectionDuration time.Duration `json:"max_connection_duration"`

	// MaxThroughputBytes is the maximum bytes that can be transferred over a connection.
	// After this threshold, the connection is rotated. Helps prevent traffic analysis.
	// Default: 500 MB (500 * 1024 * 1024)
	MaxThroughputBytes int64 `json:"max_throughput_bytes"`

	// HeartbeatMinInterval is the minimum interval between HTTP/2 PING frames.
	// Used for connection keepalive and timing obfuscation.
	// Default: 15 seconds
	HeartbeatMinInterval time.Duration `json:"heartbeat_min_interval"`

	// HeartbeatMaxInterval is the maximum interval between HTTP/2 PING frames.
	// Default: 45 seconds
	HeartbeatMaxInterval time.Duration `json:"heartbeat_max_interval"`

	// ReplayCacheSize is the maximum number of entries in the replay attack cache.
	// Default: 10000
	ReplayCacheSize int `json:"replay_cache_size"`

	// LogLevel controls the verbosity of logging output.
	// Options: "debug", "info", "warn", "error"
	// Default: "info"
	LogLevel string `json:"log_level"`

	// SSHPort is the custom SSH port for server management.
	// Default: 54321 (changed from 22 for security through obscurity)
	SSHPort int `json:"ssh_port"`
}

// DefaultConfig returns a Config initialized with production-ready defaults.
// These defaults are optimized for maximum stealth and reliability.
func DefaultConfig() *Config {
	return &Config{
		ListenPort:            1080,
		TargetDomain:          "www.facebook.com",
		ConnectionTimeout:     10 * time.Second,
		HandshakeTimeout:      5 * time.Second,
		MaxConnectionDuration: 30 * time.Minute,
		MaxThroughputBytes:    500 * 1024 * 1024, // 500 MB
		HeartbeatMinInterval:  15 * time.Second,
		HeartbeatMaxInterval:  45 * time.Second,
		ReplayCacheSize:       10000,
		LogLevel:              "info",
		SSHPort:               54321,
	}
}

// LoadFromFile reads and parses a JSON configuration file.
// It merges loaded values with defaults, ensuring all fields are populated.
func LoadFromFile(path string) (*Config, error) {
	cfg := DefaultConfig()

	file, err := os.Open(path)
	if err != nil {
		return nil, fmt.Errorf("failed to open config file: %w", err)
	}
	defer file.Close()

	decoder := json.NewDecoder(file)
	if err := decoder.Decode(cfg); err != nil {
		return nil, fmt.Errorf("failed to parse config file: %w", err)
	}

	// Resolve the target domain to IP address for fallback proxying
	if cfg.TargetDomain != "" {
		ips, err := net.LookupIP(cfg.TargetDomain)
		if err != nil {
			return nil, fmt.Errorf("failed to resolve target domain %s: %w", cfg.TargetDomain, err)
		}
		if len(ips) == 0 {
			return nil, fmt.Errorf("no IP addresses found for target domain %s", cfg.TargetDomain)
		}
		// Prefer IPv4 for broader compatibility, but fall back to IPv6
		for _, ip := range ips {
			if ip.To4() != nil {
				cfg.TargetAddr = ip
				break
			}
		}
		if cfg.TargetAddr == nil {
			cfg.TargetAddr = ips[0]
		}
		logrus.WithFields(logrus.Fields{
			"domain": cfg.TargetDomain,
			"ip":     cfg.TargetAddr.String(),
		}).Info("Resolved target domain")
	}

	if err := cfg.Validate(); err != nil {
		return nil, fmt.Errorf("config validation failed: %w", err)
	}

	return cfg, nil
}

// Validate performs comprehensive validation of the configuration.
// It checks for required fields, file existence, and valid formats.
func (c *Config) Validate() error {
	// Validate server IP if provided
	if c.ServerIP != "" {
		if ip := net.ParseIP(c.ServerIP); ip == nil {
			// Not an IP, check if it's a valid hostname
			if _, err := net.LookupHost(c.ServerIP); err != nil {
				return fmt.Errorf("invalid server_ip: must be a valid IP address or hostname")
			}
		}
	}

	// Validate listen port
	if c.ListenPort < 1 || c.ListenPort > 65535 {
		return fmt.Errorf("invalid listen_port: must be between 1 and 65535")
	}

	// Validate target domain
	if c.TargetDomain == "" {
		return fmt.Errorf("target_domain is required")
	}

	// Validate password strength
	if len(c.Password) < 16 {
		return fmt.Errorf("password must be at least 16 characters for security (current: %d)", len(c.Password))
	}
	if len(c.Password) < 32 {
		logrus.Warn("Password is shorter than recommended 32 characters - consider using a stronger password")
	}

	// Validate certificate and key files exist (for server mode)
	if c.CertFile != "" {
		if _, err := os.Stat(c.CertFile); os.IsNotExist(err) {
			return fmt.Errorf("certificate file not found: %s", c.CertFile)
		}
		// Check file permissions
		info, err := os.Stat(c.CertFile)
		if err == nil {
			if info.Mode().Perm()&0077 != 0 {
				logrus.WithField("file", c.CertFile).Warn("Certificate file has overly permissive permissions - consider chmod 600")
			}
		}
	}

	if c.KeyFile != "" {
		if _, err := os.Stat(c.KeyFile); os.IsNotExist(err) {
			return fmt.Errorf("key file not found: %s", c.KeyFile)
		}
		// Check file permissions - key file should be strictly protected
		info, err := os.Stat(c.KeyFile)
		if err == nil {
			if info.Mode().Perm()&0077 != 0 {
				logrus.WithField("file", c.KeyFile).Warn("Key file has overly permissive permissions - recommend chmod 600")
			}
		}
	}

	// Validate timeouts
	if c.ConnectionTimeout < time.Second {
		return fmt.Errorf("connection_timeout must be at least 1 second")
	}
	if c.HandshakeTimeout < time.Second {
		return fmt.Errorf("handshake_timeout must be at least 1 second")
	}
	if c.MaxConnectionDuration < time.Minute {
		return fmt.Errorf("max_connection_duration must be at least 1 minute")
	}

	// Validate heartbeat intervals
	if c.HeartbeatMinInterval >= c.HeartbeatMaxInterval {
		return fmt.Errorf("heartbeat_min_interval must be less than heartbeat_max_interval")
	}
	if c.HeartbeatMinInterval < 5*time.Second {
		return fmt.Errorf("heartbeat_min_interval must be at least 5 seconds to avoid detection")
	}

	// Validate throughput
	if c.MaxThroughputBytes < 1024*1024 { // Less than 1 MB
		return fmt.Errorf("max_throughput_bytes must be at least 1 MB")
	}

	// Validate log level
	validLogLevels := map[string]bool{
		"debug": true,
		"info":  true,
		"warn":  true,
		"error": true,
	}
	if !validLogLevels[c.LogLevel] {
		return fmt.Errorf("invalid log_level: must be one of debug, info, warn, error")
	}

	// Validate SSH port
	if c.SSHPort < 1 || c.SSHPort > 65535 {
		return fmt.Errorf("invalid ssh_port: must be between 1 and 65535")
	}
	if c.SSHPort == 22 {
		logrus.Warn("SSH port is set to default 22 - consider changing to a non-standard port for security")
	}

	return nil
}

// SaveToFile writes the configuration to a JSON file with proper formatting.
func (c *Config) SaveToFile(path string) error {
	file, err := os.Create(path)
	if err != nil {
		return fmt.Errorf("failed to create config file: %w", err)
	}
	defer file.Close()

	encoder := json.NewEncoder(file)
	encoder.SetIndent("", "  ")
	if err := encoder.Encode(c); err != nil {
		return fmt.Errorf("failed to encode config: %w", err)
	}

	return nil
}

// ConfigureLogger sets up the global logrus logger based on the configuration.
func (c *Config) ConfigureLogger() {
	level, err := logrus.ParseLevel(c.LogLevel)
	if err != nil {
		level = logrus.InfoLevel
	}
	logrus.SetLevel(level)

	// Use JSON formatter for production, text for development
	logrus.SetFormatter(&logrus.TextFormatter{
		FullTimestamp:   true,
		TimestampFormat: "2006-01-02 15:04:05",
	})
}

// String returns a sanitized string representation of the config for logging.
// Sensitive fields like passwords are redacted.
func (c *Config) String() string {
	safe := struct {
		ServerIP              string
		ListenPort            int
		TargetDomain          string
		TargetAddr            string
		Password              string // Redacted
		CertFile              string
		KeyFile               string
		ConnectionTimeout     time.Duration
		HandshakeTimeout      time.Duration
		MaxConnectionDuration time.Duration
		MaxThroughputBytes    int64
		LogLevel              string
	}{
		ServerIP:              c.ServerIP,
		ListenPort:            c.ListenPort,
		TargetDomain:          c.TargetDomain,
		TargetAddr:            c.TargetAddr.String(),
		Password:              "***REDACTED***",
		CertFile:              c.CertFile,
		KeyFile:               c.KeyFile,
		ConnectionTimeout:     c.ConnectionTimeout,
		HandshakeTimeout:      c.HandshakeTimeout,
		MaxConnectionDuration: c.MaxConnectionDuration,
		MaxThroughputBytes:    c.MaxThroughputBytes,
		LogLevel:              c.LogLevel,
	}

	data, _ := json.MarshalIndent(safe, "", "  ")
	return string(data)
}
