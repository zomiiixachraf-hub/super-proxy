# ═══════════════════════════════════════════════════════════════════════════
#                     FaceMimic - دليل التثبيت الشامل
# ═══════════════════════════════════════════════════════════════════════════

# ═══════════════════════════════════════════════════════════════════════════
# القسم الأول: هيكل الملفات والشرح
# ═══════════════════════════════════════════════════════════════════════════

## 📁 هيكل المشروع الكامل

facemimic/
│
├── 📂 core/                        # المكتبة الأساسية (لا تعدل)
│   ├── fingerprint.go              # بصمة Chrome 120 للتمويه
│   ├── masquerade.go               # تمويه HTTP/2
│   ├── handshake.go                # نظام المصادقة المخفي
│   ├── utils.go                    # دوال مساعدة
│   └── metrics.go                  # إحصائيات ومراقبة
│
├── 📂 server/                      # كود الخادم
│   └── main.go                     # البرنامج الرئيسي للخادم
│
├── 📂 client/                      # كود العميل
│   └── main.go                     # البرنامج الرئيسي للعميل
│
├── 📂 config/                      # إدارة التكوين
│   └── config.go                   # قراءة والتحقق من الإعدادات
│
├── 📂 client-configs/              # ملفات جاهزة للهاتف ⭐
│   ├── clash-template.yaml         # لـ Clash for Android
│   └── singbox-template.json       # لـ SingBox
│
├── 📄 config.json.example          # نموذج ملف الإعدادات ⭐
│
├── 📄 install-vps.sh               # تثبيت تلقائي على VPS ⭐⭐⭐
├── 📄 facemimic-manager.sh         # أداة إدارة تفاعلية ⭐⭐
├── 📄 facemimic-info.sh            # عرض معلومات الاتصال ⭐
│
├── 📄 build.sh                     # بناء البرامج
├── 📄 Makefile                     # بناء متعدد المنصات
│
├── 📄 facemimic.service            # خدمة systemd
├── 📄 Dockerfile                   # لـ Docker
├── 📄 docker-compose.yml           # تشغيل مع Docker
│
├── 📄 setup.sh                     # تقوية النظام
├── 📄 SECURITY.md                  # دليل الأمان
├── 📄 QUICK-START.md               # دليل سريع
└── 📄 README.md                    # الدليل الكامل

# ═══════════════════════════════════════════════════════════════════════════
# القسم الثاني: التثبيت على VPS
# ═══════════════════════════════════════════════════════════════════════════

## 🖥️ الطريقة الأولى: التثبيت التلقائي (الأسهل)

### الخطوة 1: اتصل بالخادم
```bash
ssh root@YOUR_SERVER_IP
```

### الخطوة 2: ثبت FaceMimic بنقرة واحدة
```bash
curl -fsSL https://your-domain.com/install-vps.sh | bash
```

أو إذا رفعت الملفات يدوياً:
```bash
cd /opt
tar -xzf facemimic-complete.tar.gz
cd facemimic
chmod +x install-vps.sh
./install-vps.sh
```

### الخطوة 3: احفظ معلومات الاتصال
```bash
facemimic-info
```

سيظهر لك:
- Server IP
- Password
- رابط الاتصال السريع

# ═══════════════════════════════════════════════════════════════════════════

## 🖥️ الطريقة الثانية: التثبيت اليدوي

### الخطوة 1: تحديث النظام
```bash
apt update && apt upgrade -y
```

### الخطوة 2: تثبيت Go
```bash
wget https://go.dev/dl/go1.22.5.linux-amd64.tar.gz
tar -C /usr/local -xzf go1.22.5.linux-amd64.tar.gz
export PATH=$PATH:/usr/local/go/bin
echo 'export PATH=$PATH:/usr/local/go/bin' >> ~/.bashrc
```

### الخطوة 3: رفع الملفات
```bash
# على جهازك المحلي
scp facemimic-complete.tar.gz root@YOUR_SERVER_IP:/opt/

# على الخادم
cd /opt
tar -xzf facemimic-complete.tar.gz
cd facemimic
```

### الخطوة 4: البناء
```bash
make all
```

### الخطوة 5: إنشاء شهادة SSL

#### إذا كان لديك نطاق (domain):
```bash
apt install certbot
certbot certonly --standalone -d your-domain.com
```

#### إذا لم يكن لديك نطاق:
```bash
mkdir -p /opt/facemimic/certs
openssl req -x509 -newkey rsa:2048 \
    -keyout /opt/facemimic/certs/key.pem \
    -out /opt/facemimic/certs/cert.pem \
    -days 365 -nodes \
    -subj "/CN=www.facebook.com"
```

### الخطوة 6: إنشاء ملف التكوين
```bash
# توليد كلمة مرور قوية
PASSWORD=$(openssl rand -base64 32)

# الحصول على IP الخادم
SERVER_IP=$(curl -s ifconfig.me)

# إنشاء ملف التكوين
cat > /opt/facemimic/config.json << EOF
{
    "server_ip": "$SERVER_IP",
    "listen_port": 1080,
    "target_domain": "www.facebook.com",
    "password": "$PASSWORD",
    "cert_file": "/etc/letsencrypt/live/your-domain.com/fullchain.pem",
    "key_file": "/etc/letsencrypt/live/your-domain.com/privkey.pem",
    "connection_timeout": "10s",
    "handshake_timeout": "5s",
    "max_connection_duration": "30m",
    "max_throughput_bytes": 524288000,
    "heartbeat_min_interval": "15s",
    "heartbeat_max_interval": "45s",
    "replay_cache_size": 10000,
    "log_level": "info"
}
EOF
```

### الخطوة 7: تثبيت الخدمة
```bash
cp facemimic.service /etc/systemd/system/
systemctl daemon-reload
systemctl enable facemimic
systemctl start facemimic
```

### الخطوة 8: فتح المنافذ
```bash
ufw allow 80/tcp
ufw allow 443/tcp
ufw enable
```

# ═══════════════════════════════════════════════════════════════════════════
# القسم الثالث: إعداد الهاتف
# ═══════════════════════════════════════════════════════════════════════════

## 📱 الطريقة الأولى: Clash for Android (الأسهل)

### الخطوة 1: تحميل التطبيق
- من Google Play: ابحث عن "Clash for Android"
- أو من GitHub: github.com/Kr328/ClashForAndroid

### الخطوة 2: تجهيز ملف التكوين

على الخادم:
```bash
# عرض ملف التكوين
cat /opt/facemimic/client-configs/clash.yaml

# أو إنشاء ملف جديد
IP=$(curl -s ifconfig.me)
PASS=$(grep -o '"password": "[^"]*"' /opt/facemimic/config.json | cut -d'"' -f4)

cat > /opt/facemimic/client-configs/my-clash.yaml << EOF
port: 7890
socks-port: 7891
allow-lan: true
mode: Rule

proxies:
  - name: "FaceMimic"
    type: socks5
    server: 127.0.0.1
    port: 1080

proxy-groups:
  - name: "Proxy"
    type: select
    proxies:
      - FaceMimic
      - DIRECT

rules:
  - MATCH,Proxy
EOF
```

### الخطوة 3: نقل الملف للهاتف
- الطريقة أ: ارسل الملف لنفسك عبر Telegram/Email
- الطريقة ب: استخدم USB
- الطريقة ج: افتح IP:8080 في متصفح الهاتف وحمّل

### الخطوة 4: استيراد في التطبيق
1. افتح Clash for Android
2. اضغط على "Profiles"
3. اضغط على "+"
4. اختر "File"
5. اختر ملف clash.yaml
6. اضغط على الملف لتفعيله
7. اضغط على "Start"

# ═══════════════════════════════════════════════════════════════════════════

## 📱 الطريقة الثانية: SingBox

### الخطوة 1: تحميل التطبيق
- من Google Play: ابحث عن "SingBox"
- أو من GitHub: github.com/SagerNet/sing-box

### الخطوة 2: استيراد التكوين
1. افتح التطبيق
2. اضغط على "+" 
3. اختر "Import Profile"
4. الصق محتوى ملف singbox.json

# ═══════════════════════════════════════════════════════════════════════════

## 📱 الطريقة الثالثة: أي تطبيق SOCKS5

أدخل هذه البيانات في أي تطبيق يدعم SOCKS5:

```
نوع البروكسي: SOCKS5
عنوان الخادم: YOUR_SERVER_IP
المنفذ: 1080
كلمة المرور: YOUR_PASSWORD
```

تطبيقات مقترحة:
- Drony
- Postern  
- Every Proxy
- ProxyDroid

# ═══════════════════════════════════════════════════════════════════════════
# القسم الرابع: إدارة الخادم
# ═══════════════════════════════════════════════════════════════════════════

## 🔧 أوامر الخدمة

```bash
# بدء الخدمة
systemctl start facemimic

# إيقاف الخدمة
systemctl stop facemimic

# إعادة التشغيل
systemctl restart facemimic

# عرض الحالة
systemctl status facemimic

# عرض السجلات
journalctl -u facemimic -f

# تفعيل التشغيل التلقائي
systemctl enable facemimic
```

## 🔧 أداة الإدارة التفاعلية

```bash
facemimic-manager
```

ستظهر قائمة بالخيارات:
1. عرض الحالة
2. عرض معلومات الاتصال
3. تغيير كلمة المرور
4. إعادة التشغيل
5. عرض السجلات
6. تصدير ملفات التكوين
7. فتح لوحة التحكم
8. تحديث البرنامج
9. إلغاء التثبيت

## 🔧 عرض معلومات الاتصال

```bash
facemimic-info
```

## 🔧 تغيير كلمة المرور

```bash
# توليد كلمة جديدة
NEW_PASS=$(openssl rand -base64 32)

# تحديث التكوين
sed -i "s/\"password\": \"[^\"]*\"/\"password\": \"$NEW_PASS\"/" /opt/facemimic/config.json

# إعادة التشغيل
systemctl restart facemimic

# عرض كلمة المرور الجديدة
echo "New Password: $NEW_PASS"
```

# ═══════════════════════════════════════════════════════════════════════════
# القسم الخامس: شرح ملف التكوين
# ═══════════════════════════════════════════════════════════════════════════

## 📄 config.json

```json
{
    // IP الخادم (يُملأ تلقائياً)
    "server_ip": "203.0.113.50",
    
    // منفذ SOCKS5 المحلي
    "listen_port": 1080,
    
    // النطاق المُمَوَّه (لا تغيره)
    "target_domain": "www.facebook.com",
    
    // كلمة المرور (32 حرف على الأقل)
    "password": "your-secure-password-here",
    
    // مسار شهادة SSL
    "cert_file": "/etc/letsencrypt/live/domain.com/fullchain.pem",
    
    // مسار مفتاح SSL
    "key_file": "/etc/letsencrypt/live/domain.com/privkey.pem",
    
    // مهلة الاتصال
    "connection_timeout": "10s",
    
    // مهلة المصافحة
    "handshake_timeout": "5s",
    
    // أقصى مدة للاتصال (قبل التدوير)
    "max_connection_duration": "30m",
    
    // أقصى كمية بيانات (قبل التدوير)
    "max_throughput_bytes": 524288000,
    
    // فترة نبضات القلب
    "heartbeat_min_interval": "15s",
    "heartbeat_max_interval": "45s",
    
    // حجم ذاكرة منع إعادة التشغيل
    "replay_cache_size": 10000,
    
    // مستوى التسجيل
    "log_level": "info"
}
```

# ═══════════════════════════════════════════════════════════════════════════
# القسم السادس: استكشاف الأخطاء
# ═══════════════════════════════════════════════════════════════════════════

## ❌ المشكلة: الخدمة لا تعمل

```bash
# تحقق من الحالة
systemctl status facemimic

# تحقق من السجلات
journalctl -u facemimic -n 50

# تحقق من الملفات
ls -la /opt/facemimic/

# تحقق من المنافذ
netstat -tlnp | grep -E '80|443'
```

## ❌ المشكلة: لا يمكن الاتصال من الهاتف

1. تأكد من أن الخدمة تعمل:
```bash
systemctl status facemimic
```

2. تأكد من فتح المنافذ:
```bash
ufw status
```

3. تأكد من صحة IP:
```bash
curl ifconfig.me
```

4. تأكد من صحة كلمة المرور:
```bash
grep password /opt/facemimic/config.json
```

## ❌ المشكلة: بطء الاتصال

1. تحقق من موقع الخادم (اختر قريب منك)
2. تحقق من سرعة الخادم:
```bash
speedtest-cli
```

## ❌ المشكلة: شهادة SSL منتهية

```bash
# تجديد الشهادة
certbot renew

# إعادة تشغيل الخدمة
systemctl restart facemimic
```

# ═══════════════════════════════════════════════════════════════════════════
# القسم السابع: نصائح مهمة
# ═══════════════════════════════════════════════════════════════════════════

## ⚠️ تحذيرات أمنية

1. استخدم خادم في ASN يخدم Facebook
2. غيّر كلمة المرور كل أسبوعين
3. راقب السجلات بانتظام
4. لا تشارك كلمة المرور مع أحد
5. استخدم شهادة SSL صالحة

## ✅ أفضل الممارسات

1. اختر خادم قريب جغرافياً
2. استخدم نطاق (domain) حقيقي
3. فعّل الترقية التلقائية للشهادة:
```bash
certbot renew --dry-run
```

4. احتفظ بنسخة احتياطية:
```bash
tar -czf facemimic-backup.tar.gz /opt/facemimic/
```

5. راقب الموارد:
```bash
htop
```

# ═══════════════════════════════════════════════════════════════════════════
# القسم الثامن: الأسئلة الشائعة
# ═══════════════════════════════════════════════════════════════════════════

## س: هل يعمل على جميع الأجهزة؟
ج: نعم، يعمل على Android و Windows و macOS و Linux

## س: هل يحجب المواقع المحلية؟
ج: لا، يمكنك إضافة قواعد لتوجيه المواقع المحلية مباشرة

## س: كم سرعة الاتصال؟
ج: يعتمد على سرعة الخادم، عادة 50-200 Mbps

## س: هل يُكشف؟
ج: مصمم ليكون غير قابل للكشف بفضل التمويه الكامل

## س: كيف أحدّث البرنامج؟
ج: نزّل الإصدار الجديد وأعد التثبيت

# ═══════════════════════════════════════════════════════════════════════════
# الدعم الفني
# ═══════════════════════════════════════════════════════════════════════════

GitHub: https://github.com/facemimic/core
Telegram: @facemimic_support
Email: support@facemimic.io
