#!/bin/bash
#
# FaceMimic Server Setup Script
# This script performs system hardening and configuration for optimal
# anti-censorship tunnel operation.
#
# Usage: sudo ./setup.sh
#
# CRITICAL: Run this script on a freshly installed server before deployment.
#           This script modifies system settings that require root privileges.
#

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Logging function
log_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

log_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    log_error "Please run as root (sudo ./setup.sh)"
    exit 1
fi

log_info "Starting FaceMimic server setup..."

# ============================================
# SECTION 1: TIME SYNCHRONIZATION
# ============================================
log_info "Configuring time synchronization (critical for HMAC authentication)..."

# Install chrony for better time synchronization
if ! command -v chrony &> /dev/null; then
    log_info "Installing chrony..."
    apt-get update -qq
    apt-get install -y chrony
fi

# Configure chrony to use Facebook's NTP server
# This is important because our system mimics Facebook
cat > /etc/chrony/chrony.conf << 'EOF'
# Use Facebook's NTP server for time synchronization
# This is consistent with the Facebook mimicry theme
server time.facebook.com iburst
server time1.facebook.com iburst
server time2.facebook.com iburst
server time3.facebook.com iburst

# Allow NTP client access from local network
allow localhost

# Serve time even if not synchronized to a time source
local stratum 10

# Record the rate at which the system clock gains/loses time
driftfile /var/lib/chrony/drift

# Enable kernel synchronization of the real-time clock (RTC)
rtcsync

# Enable hardware timestamping on all interfaces that support it
hwtimestamp *

# Increase the minimum number of selectable sources required to adjust
# the system clock
minsources 2

# Get TAI-UTC offset and leap seconds from the system tz database
leapsectz right/UTC
EOF

# Restart chrony and force immediate synchronization
systemctl restart chrony
chronyc makestep 2>/dev/null || true

# Verify time sync
log_info "Current time synchronization status:"
chronyc tracking 2>/dev/null || timedatectl status

# ============================================
# SECTION 2: KERNEL PARAMETERS
# ============================================
log_info "Configuring kernel parameters for optimal network performance..."

# Create sysctl configuration
cat > /etc/sysctl.d/99-facemimic.conf << 'EOF'
# ============================================
# Network Performance Tuning
# ============================================

# Increase system file descriptor limits
fs.file-max = 1048576

# Increase network buffer sizes for high throughput
net.core.rmem_max = 16777216
net.core.wmem_max = 16777216
net.core.rmem_default = 262144
net.core.wmem_default = 262144

# TCP buffer tuning
net.ipv4.tcp_rmem = 4096 87380 16777216
net.ipv4.tcp_wmem = 4096 65536 16777216

# Increase the maximum amount of option memory buffers
net.core.optmem_max = 65536

# Increase number of incoming connections backlog
net.core.somaxconn = 65535
net.core.netdev_max_backlog = 65535

# TCP Fast Open (reduce latency for new connections)
net.ipv4.tcp_fastopen = 3

# Use BBR congestion control algorithm for better throughput
# BBR is less sensitive to packet loss and works well on congested networks
net.core.default_qdisc = fq
net.ipv4.tcp_congestion_control = bbr

# Enable TCP timestamps for RTT calculation
net.ipv4.tcp_timestamps = 1

# Security: Ignore ICMP timestamp requests
net.ipv4.icmp_echo_ignore_timestamps = 1

# Security: Disable ICMP redirects
net.ipv4.conf.all.accept_redirects = 0
net.ipv4.conf.default.accept_redirects = 0
net.ipv6.conf.all.accept_redirects = 0
net.ipv6.conf.default.accept_redirects = 0

# Security: Don't send ICMP redirects
net.ipv4.conf.all.send_redirects = 0
net.ipv4.conf.default.send_redirects = 0

# Security: Enable TCP SYN cookies for SYN flood protection
net.ipv4.tcp_syncookies = 1

# Increase TCP SYN backlog
net.ipv4.tcp_max_syn_backlog = 65535

# Increase number of available ports
net.ipv4.ip_local_port_range = 1024 65535

# Reduce TCP FIN timeout for faster connection recycling
net.ipv4.tcp_fin_timeout = 15

# Reduce TCP keepalive settings for dead connection detection
net.ipv4.tcp_keepalive_time = 300
net.ipv4.tcp_keepalive_intvl = 30
net.ipv4.tcp_keepalive_probes = 5

# Enable TCP MTU probing
net.ipv4.tcp_mtu_probing = 1

# Security: Reverse path filtering
net.ipv4.conf.all.rp_filter = 1
net.ipv4.conf.default.rp_filter = 1

# Security: Log martian packets
net.ipv4.conf.all.log_martians = 1
net.ipv4.conf.default.log_martians = 1

# Memory tuning for high connection count
vm.swappiness = 10
vm.dirty_ratio = 60
vm.dirty_background_ratio = 2

# ============================================
# Connection Tracking (for NAT/firewall)
# ============================================
net.netfilter.nf_conntrack_max = 1048576
net.netfilter.nf_conntrack_tcp_timeout_established = 7200
EOF

# Apply sysctl settings
sysctl -p /etc/sysctl.d/99-facemimic.conf

log_info "Kernel parameters configured."

# ============================================
# SECTION 3: FILE DESCRIPTOR LIMITS
# ============================================
log_info "Configuring file descriptor limits..."

# Create limits configuration
cat > /etc/security/limits.d/99-facemimic.conf << 'EOF'
# Increase file descriptor limits for FaceMimic
# Required for handling many concurrent connections

# Soft and hard limits for all users
* soft nofile 1048576
* hard nofile 1048576

# Root needs higher limits
root soft nofile 1048576
root hard nofile 1048576

# Increase maximum processes
* soft nproc 65535
* hard nproc 65535
root soft nproc 65535
root hard nproc 65535
EOF

# Also update pam_limits
if ! grep -q "session required pam_limits.so" /etc/pam.d/common-session; then
    echo "session required pam_limits.so" >> /etc/pam.d/common-session
fi

log_info "File descriptor limits configured."

# ============================================
# SECTION 4: SSH HARDENING
# ============================================
log_info "Configuring SSH security..."

SSH_PORT=${SSH_PORT:-54321}

# Backup original sshd_config
cp /etc/ssh/sshd_config /etc/ssh/sshd_config.backup

# Modify SSH configuration
sed -i "s/#Port 22/Port $SSH_PORT/" /etc/ssh/sshd_config
sed -i "s/^Port 22/Port $SSH_PORT/" /etc/ssh/sshd_config

# Additional SSH hardening
sed -i 's/#PermitRootLogin yes/PermitRootLogin no/' /etc/ssh/sshd_config
sed -i 's/^PermitRootLogin yes/PermitRootLogin no/' /etc/ssh/sshd_config
sed -i 's/#PasswordAuthentication yes/PasswordAuthentication no/' /etc/ssh/sshd_config
sed -i 's/^PasswordAuthentication yes/PasswordAuthentication no/' /etc/ssh/sshd_config
sed -i 's/#PubkeyAuthentication yes/PubkeyAuthentication yes/' /etc/ssh/sshd_config

# Restart SSH
log_warn "SSH port changed to $SSH_PORT. Make sure you have SSH key authentication configured!"
log_warn "Restarting SSH service..."
systemctl restart sshd

log_info "SSH hardening complete."

# ============================================
# SECTION 5: FIREWALL CONFIGURATION
# ============================================
log_info "Configuring firewall..."

# Install UFW if not present
if ! command -v ufw &> /dev/null; then
    apt-get install -y ufw
fi

# Reset UFW to clean state
ufw --force reset

# Default policies
ufw default deny incoming
ufw default allow outgoing

# Allow SSH on custom port
ufw allow $SSH_PORT/tcp comment 'SSH access'

# Allow HTTP (decoy server)
ufw allow 80/tcp comment 'HTTP decoy'

# Allow HTTPS (tunnel server)
ufw allow 443/tcp comment 'HTTPS tunnel'

# Enable logging
ufw logging on

# Enable firewall
ufw --force enable

log_info "Firewall configured."

# ============================================
# SECTION 6: QUIC BLACKHOLE
# ============================================
log_info "Blocking QUIC traffic to prevent protocol exposure..."

# Block QUIC (UDP 443) to prevent accidental exposure
# This ensures only TLS over TCP is used
iptables -I INPUT -p udp --dport 443 -j DROP
iptables -I INPUT -p udp --sport 443 -j DROP

# Make iptables rules persistent
if ! command -v iptables-save &> /dev/null; then
    apt-get install -y iptables-persistent
fi

# Save rules
iptables-save > /etc/iptables/rules.v4 2>/dev/null || true
ip6tables-save > /etc/iptables/rules.v6 2>/dev/null || true

log_info "QUIC traffic blocked."

# ============================================
# SECTION 7: DNS CONFIGURATION
# ============================================
log_info "Configuring DNS resolution..."

# Use Cloudflare and Google DNS for reliable resolution
# These are commonly used and won't raise suspicion
cat > /etc/resolv.conf << 'EOF'
# Cloudflare DNS
nameserver 1.1.1.1
nameserver 1.0.0.1
# Google DNS (backup)
nameserver 8.8.8.8
nameserver 8.8.4.4
# IPv6
nameserver 2606:4700:4700::1111
nameserver 2001:4860:4860::8888
EOF

# Prevent resolvconf from overwriting
chattr +i /etc/resolv.conf 2>/dev/null || true

log_info "DNS configured."

# ============================================
# SECTION 8: SYSTEM CLEANUP
# ============================================
log_info "Performing system cleanup..."

# Remove unnecessary services that could expose the server
DISABLE_SERVICES=(
    "apache2"
    "nginx"
    "postfix"
    "dovecot"
    "vsftpd"
    "proftpd"
)

for service in "${DISABLE_SERVICES[@]}"; do
    if systemctl is-active --quiet "$service" 2>/dev/null; then
        log_info "Stopping $service..."
        systemctl stop "$service" 2>/dev/null || true
        systemctl disable "$service" 2>/dev/null || true
    fi
done

# Clear bash history
history -c
rm -f ~/.bash_history
ln -sf /dev/null ~/.bash_history

log_info "System cleanup complete."

# ============================================
# SECTION 9: CREATE SAMPLE CONFIG
# ============================================
log_info "Creating sample configuration file..."

mkdir -p /opt/facemimic

cat > /opt/facemimic/config.json.example << 'EOF'
{
    "server_ip": "YOUR_SERVER_IP",
    "listen_port": 1080,
    "target_domain": "www.facebook.com",
    "password": "YOUR_SECURE_PASSWORD_MIN_32_CHARS_CHANGE_THIS",
    "cert_file": "/etc/letsencrypt/live/your.domain.com/fullchain.pem",
    "key_file": "/etc/letsencrypt/live/your.domain.com/privkey.pem",
    "connection_timeout": "10s",
    "handshake_timeout": "5s",
    "max_connection_duration": "30m",
    "max_throughput_bytes": 524288000,
    "heartbeat_min_interval": "15s",
    "heartbeat_max_interval": "45s",
    "replay_cache_size": 10000,
    "log_level": "info",
    "ssh_port": 54321
}
EOF

log_info "Sample configuration created at /opt/facemimic/config.json.example"

# ============================================
# SECTION 10: SUMMARY
# ============================================
echo ""
echo "=========================================="
log_info "FaceMimic Server Setup Complete!"
echo "=========================================="
echo ""
echo "Important Information:"
echo "  - SSH Port: $SSH_PORT"
echo "  - HTTP Port: 80 (decoy)"
echo "  - HTTPS Port: 443 (tunnel)"
echo "  - QUIC Blocked: Yes (UDP 443)"
echo ""
echo "Next Steps:"
echo "  1. Copy your TLS certificate to the server"
echo "  2. Copy config.json.example to config.json and edit it"
echo "  3. Run ./build.sh to compile the binaries"
echo "  4. Copy facemimic.service to /etc/systemd/system/"
echo "  5. Run: systemctl enable --now facemimic"
echo ""
log_warn "Remember to update your SSH client config to use port $SSH_PORT!"
log_warn "Remember to set up your TLS certificate (certbot recommended)!"
echo ""
