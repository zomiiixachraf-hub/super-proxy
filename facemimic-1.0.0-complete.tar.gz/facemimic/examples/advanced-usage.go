// Example: Advanced FaceMimic Usage
// This file demonstrates advanced usage patterns and extensions

package main

import (
	"context"
	"crypto/tls"
	"fmt"
	"net"
	"time"

	"github.com/facemimic/core/config"
	"github.com/facemimic/core/core"
	utls "github.com/refraction-networking/utls"
	"github.com/sirupsen/logrus"
)

// Example 1: Custom TLS Configuration
// Shows how to create a custom TLS configuration with specific fingerprints

func CreateCustomTLSConfig(domain string, sessionID []byte) *utls.Config {
	return &utls.Config{
		ServerName:         domain,
		InsecureSkipVerify: false, // Set to true only for testing
		SessionID:          sessionID,
		NextProtos:         []string{"h2", "http/1.1"},
		MinVersion:         tls.VersionTLS12,
		MaxVersion:         tls.VersionTLS13,
		CipherSuites: []uint16{
			// TLS 1.3 cipher suites (automatically used)
			// TLS 1.2 cipher suites for fallback
			tls.TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384,
			tls.TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384,
			tls.TLS_ECDHE_ECDSA_WITH_CHACHA20_POLY1305,
			tls.TLS_ECDHE_RSA_WITH_CHACHA20_POLY1305,
		},
	}
}

// Example 2: Connection Pool Manager
// Manages a pool of connections for high-throughput scenarios

type ConnectionPool struct {
	connections chan *PooledConnection
	maxSize     int
	factory     func() (*PooledConnection, error)
}

type PooledConnection struct {
	net.Conn
	createdAt time.Time
	bytesIn   uint64
	bytesOut  uint64
}

func NewConnectionPool(maxSize int, factory func() (*PooledConnection, error)) *ConnectionPool {
	pool := &ConnectionPool{
		connections: make(chan *PooledConnection, maxSize),
		maxSize:     maxSize,
		factory:     factory,
	}

	// Pre-populate pool
	for i := 0; i < maxSize/2; i++ {
		conn, err := factory()
		if err == nil {
			pool.connections <- conn
		}
	}

	return pool
}

func (p *ConnectionPool) Get() (*PooledConnection, error) {
	select {
	case conn := <-p.connections:
		return conn, nil
	default:
		return p.factory()
	}
}

func (p *ConnectionPool) Put(conn *PooledConnection) {
	select {
	case p.connections <- conn:
		// Returned to pool
	default:
		// Pool full, close connection
		conn.Close()
	}
}

// Example 3: Custom Traffic Shaping
// Implements traffic shaping to avoid detection patterns

type TrafficShaper struct {
	minInterval time.Duration
	maxInterval time.Duration
	maxBurst    int
	bucket      int
	lastSend    time.Time
}

func NewTrafficShaper(minInterval, maxInterval time.Duration, maxBurst int) *TrafficShaper {
	return &TrafficShaper{
		minInterval: minInterval,
		maxInterval: maxInterval,
		maxBurst:    maxBurst,
		bucket:      maxBurst,
		lastSend:    time.Now(),
	}
}

func (ts *TrafficShaper) Wait() {
	// Leaky bucket algorithm
	now := time.Now()
	elapsed := now.Sub(ts.lastSend)

	// Refill bucket
	ts.bucket += int(elapsed / ts.minInterval)
	if ts.bucket > ts.maxBurst {
		ts.bucket = ts.maxBurst
	}

	if ts.bucket > 0 {
		ts.bucket--
		ts.lastSend = now
		return
	}

	// Wait for next available token
	waitTime := ts.minInterval - elapsed
	time.Sleep(waitTime)
	ts.lastSend = time.Now()
}

// Example 4: Metrics Exporter
// Exports metrics in Prometheus format

func ExportMetricsPrometheus() string {
	snapshot := core.GlobalMetrics.Snapshot()

	return fmt.Sprintf(`
# HELP facemimic_connections_total Total connections accepted
# TYPE facemimic_connections_total counter
facemimic_connections_total %d

# HELP facemimic_connections_active Currently active connections
# TYPE facemimic_connections_active gauge
facemimic_connections_active %d

# HELP facemimic_bytes_sent_total Total bytes sent
# TYPE facemimic_bytes_sent_total counter
facemimic_bytes_sent_total %d

# HELP facemimic_bytes_received_total Total bytes received
# TYPE facemimic_bytes_received_total counter
facemimic_bytes_received_total %d

# HELP facemimic_auth_success_total Successful authentications
# TYPE facemimic_auth_success_total counter
facemimic_auth_success_total %d

# HELP facemimic_auth_failure_total Failed authentications
# TYPE facemimic_auth_failure_total counter
facemimic_auth_failure_total %d

# HELP facemimic_probes_rejected_total Rejected probe attempts
# TYPE facemimic_probes_rejected_total counter
facemimic_probes_rejected_total %d

# HELP facemimic_uptime_seconds Server uptime in seconds
# TYPE facemimic_uptime_seconds gauge
facemimic_uptime_seconds %.0f
`,
		snapshot.TotalConnections,
		snapshot.ActiveConnections,
		snapshot.BytesSent,
		snapshot.BytesReceived,
		snapshot.AuthSuccesses,
		snapshot.AuthFailures,
		snapshot.RejectedProbes,
		snapshot.Uptime.Seconds(),
	)
}

// Example 5: Custom Authentication Provider
// Allows custom authentication mechanisms

type AuthProvider interface {
	GenerateSessionID() ([]byte, error)
	ValidateSessionID(sessionID []byte) (bool, int64)
}

type HMACAuthProvider struct {
	secret string
	cache  *core.ReplayCache
}

func NewHMACAuthProvider(secret string) *HMACAuthProvider {
	return &HMACAuthProvider{
		secret: secret,
		cache:  core.NewReplayCache(10000),
	}
}

func (p *HMACAuthProvider) GenerateSessionID() ([]byte, error) {
	return core.GenerateSessionID(time.Now().Unix(), p.secret), nil
}

func (p *HMACAuthProvider) ValidateSessionID(sessionID []byte) (bool, int64) {
	valid, timestamp, _ := core.ValidateSessionID(sessionID, p.secret)
	if !valid {
		return false, 0
	}

	// Check replay
	if !p.cache.CheckAndStore(sessionID, timestamp) {
		return false, 0
	}

	return true, timestamp
}

// Example 6: Connection Event Hooks
// Allows custom handling of connection events

type ConnectionHooks struct {
	OnConnect    func(remoteAddr string)
	OnDisconnect func(remoteAddr string, duration time.Duration, bytes uint64)
	OnAuth       func(remoteAddr string, success bool)
	OnError      func(remoteAddr string, err error)
}

func (h *ConnectionHooks) HandleConnect(remoteAddr string) {
	if h.OnConnect != nil {
		h.OnConnect(remoteAddr)
	}
}

func (h *ConnectionHooks) HandleDisconnect(remoteAddr string, duration time.Duration, bytes uint64) {
	if h.OnDisconnect != nil {
		h.OnDisconnect(remoteAddr, duration, bytes)
	}
}

// Example usage
func main() {
	logrus.Info("FaceMimic Advanced Examples")

	// Load config
	cfg, err := config.LoadFromFile("config.json")
	if err != nil {
		logrus.Fatalf("Failed to load config: %v", err)
	}

	// Create auth provider
	auth := NewHMACAuthProvider(cfg.Password)

	// Generate session ID
	sessionID, err := auth.GenerateSessionID()
	if err != nil {
		logrus.Fatalf("Failed to generate session ID: %v", err)
	}

	logrus.Infof("Generated Session ID: %x", sessionID[:8])

	// Validate it
	valid, timestamp := auth.ValidateSessionID(sessionID)
	logrus.Infof("Validation: valid=%v, timestamp=%d", valid, timestamp)

	// Export metrics
	metricsOutput := ExportMetricsPrometheus()
	logrus.Info("Metrics exported (Prometheus format)")
	fmt.Println(metricsOutput[:200] + "...")

	// Traffic shaper example
	shaper := NewTrafficShaper(10*time.Millisecond, 50*time.Millisecond, 10)
	logrus.Info("Traffic shaper configured")

	// Simulate traffic
	for i := 0; i < 5; i++ {
		shaper.Wait()
		logrus.Debugf("Sent packet %d", i)
	}
}
