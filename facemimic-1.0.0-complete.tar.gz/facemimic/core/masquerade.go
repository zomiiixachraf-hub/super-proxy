// Package core provides HTTP/2 traffic morphing capabilities for the FaceMimic protocol.
// This module implements the obfuscation layer that makes tunneled traffic appear as
// legitimate HTTP/2 web traffic from Chrome browser visiting Facebook.
package core

import (
	"bytes"
	"context"
	"encoding/binary"
	"errors"
	"io"
	"math/rand"
	"net"
	"sync"
	"time"

	"github.com/sirupsen/logrus"
)

// HTTP/2 Frame Types as defined in RFC 7540
const (
	FrameData         = 0x0
	FrameHeaders      = 0x1
	FramePriority     = 0x2
	FrameRSTStream    = 0x3
	FrameSettings     = 0x4
	FramePushPromise  = 0x5
	FramePing         = 0x6
	FrameGoAway       = 0x7
	FrameWindowUpdate = 0x8
	FrameContinuation = 0x9
)

// HTTP/2 Frame Flags
const (
	FlagEndStream  = 0x1
	FlagEndHeaders = 0x4
	FlagPadded     = 0x8
	FlagAck        = 0x1 // For Settings and Ping frames
	FlagPriority   = 0x20
)

// HTTP/2 Settings Parameters
const (
	SettingsHeaderTableSize      = 0x1
	SettingsEnablePush           = 0x2
	SettingsMaxConcurrentStreams = 0x3
	SettingsInitialWindowSize    = 0x4
	SettingsMaxFrameSize         = 0x5
	SettingsMaxHeaderListSize    = 0x6
)

// Errors
var (
	ErrInvalidFrame     = errors.New("invalid HTTP/2 frame")
	ErrConnectionClosed = errors.New("connection closed")
	ErrBufferOverflow   = errors.New("buffer overflow")
)

// ChromeExactSettings returns HTTP/2 settings exactly matching Chrome 120.
func ChromeExactSettings() []SettingsParameter {
	return []SettingsParameter{
		{ID: SettingsHeaderTableSize, Value: 65536},
		{ID: SettingsEnablePush, Value: 0},
		{ID: SettingsMaxConcurrentStreams, Value: 1000},
		{ID: SettingsInitialWindowSize, Value: 6291456},
		{ID: SettingsMaxFrameSize, Value: 16384},
		{ID: SettingsMaxHeaderListSize, Value: 262144},
	}
}

// SettingsParameter represents a single HTTP/2 settings parameter
type SettingsParameter struct {
	ID    uint16
	Value uint32
}

// H2Conn wraps a net.Conn and provides HTTP/2 framing for tunnel data.
// All data is encapsulated as HTTP/2 DATA frames with Chrome-like padding
// to normalize packet sizes and evade traffic analysis.
type H2Conn struct {
	conn         net.Conn
	reader       *bytes.Reader
	writeMu      sync.Mutex
	readMu       sync.Mutex
	rand         *rand.Rand
	maxFrameSize uint32
	windowSize   uint32
	windowMu     sync.Mutex
	closed       bool
	closeMu      sync.RWMutex

	// Stream management
	nextStreamID uint32
	streamMu     sync.Mutex

	// Statistics
	bytesSent     uint64
	bytesReceived uint64
	startTime     time.Time

	// Facebook profile
	profile *FacebookProfile
}

// H2Config holds configuration for the H2Conn
type H2Config struct {
	MaxFrameSize      uint32
	InitialWindowSize uint32
	MinPadding        int
	MaxPadding        int
	HeartbeatInterval time.Duration
	Profile           *FacebookProfile
}

// DefaultH2Config returns a production-ready H2Config matching Chrome
func DefaultH2Config() H2Config {
	return H2Config{
		MaxFrameSize:      16384,
		InitialWindowSize: 6291456, // 6MB - Chrome default
		MinPadding:        0,
		MaxPadding:        255,
		HeartbeatInterval: 30 * time.Second,
		Profile:           DefaultFacebookProfile(),
	}
}

// NewH2Conn creates a new HTTP/2 masquerading connection wrapper.
func NewH2Conn(conn net.Conn, config H2Config) *H2Conn {
	h2 := &H2Conn{
		conn:          conn,
		reader:        bytes.NewReader(nil),
		maxFrameSize:  config.MaxFrameSize,
		windowSize:    config.InitialWindowSize,
		rand:          rand.New(rand.NewSource(time.Now().UnixNano())),
		startTime:     time.Now(),
		nextStreamID:  1, // Client-initiated streams use odd numbers
		profile:       config.Profile,
	}

	return h2
}

// Write frames the data as an HTTP/2 DATA frame and sends it.
// It uses Chrome-like padding to normalize packet sizes.
func (h2 *H2Conn) Write(p []byte) (n int, err error) {
	h2.closeMu.RLock()
	if h2.closed {
		h2.closeMu.RUnlock()
		return 0, ErrConnectionClosed
	}
	h2.closeMu.RUnlock()

	h2.writeMu.Lock()
	defer h2.writeMu.Unlock()

	// Split large payloads into multiple frames (Chrome behavior)
	offset := 0
	for offset < len(p) {
		chunkSize := len(p) - offset
		if chunkSize > int(h2.maxFrameSize) {
			chunkSize = int(h2.maxFrameSize)
		}

		chunk := p[offset : offset+chunkSize]

		// Calculate Chrome-like padding
		paddingLen := CalculatePadding(len(chunk), 1500)

		// Determine if this is the last chunk
		endStream := offset+chunkSize >= len(p)

		// Create the frame with Chrome-like behavior
		frame, err := h2.createDataFrameChrome(chunk, paddingLen, endStream)
		if err != nil {
			return offset, err
		}

		// Add realistic inter-frame delay for small frames
		if len(chunk) < 1024 {
			delay := GenerateRealisticDelay(1, 10)
			time.Sleep(delay)
		}

		// Write the frame
		written, err := h2.conn.Write(frame)
		if err != nil {
			return offset, err
		}

		h2.bytesSent += uint64(written)
		offset += chunkSize
	}

	return len(p), nil
}

// createDataFrameChrome creates an HTTP/2 DATA frame matching Chrome's format.
func (h2 *H2Conn) createDataFrameChrome(payload []byte, paddingLen int, endStream bool) ([]byte, error) {
	length := len(payload) + paddingLen
	if paddingLen > 0 {
		length++ // Account for padding length byte
	}

	if length > 1<<24-1 {
		return nil, ErrBufferOverflow
	}

	buf := make([]byte, 9+length)

	// Write length (24 bits, big endian)
	buf[0] = byte(length >> 16)
	buf[1] = byte(length >> 8)
	buf[2] = byte(length)

	// Write type (DATA = 0x0)
	buf[3] = FrameData

	// Write flags - Chrome style
	flags := byte(0)
	if paddingLen > 0 {
		flags |= FlagPadded
	}
	if endStream {
		flags |= FlagEndStream
	}
	buf[4] = flags

	// Get stream ID (use odd numbers for client-initiated)
	h2.streamMu.Lock()
	streamID := h2.nextStreamID
	h2.streamMu.Unlock()
	binary.BigEndian.PutUint32(buf[5:9], streamID)

	// Write padding length if padded
	if paddingLen > 0 {
		buf[9] = byte(paddingLen)
		copy(buf[10:], payload)
		// Padding bytes are already zero
	} else {
		copy(buf[9:], payload)
	}

	return buf, nil
}

// Read reads data from the underlying connection, stripping HTTP/2 frame headers.
func (h2 *H2Conn) Read(p []byte) (n int, err error) {
	h2.closeMu.RLock()
	if h2.closed {
		h2.closeMu.RUnlock()
		return 0, ErrConnectionClosed
	}
	h2.closeMu.RUnlock()

	h2.readMu.Lock()
	defer h2.readMu.Unlock()

	// If we have buffered data from a previous frame, return it
	if h2.reader.Len() > 0 {
		return h2.reader.Read(p)
	}

	// Read next frame
	for {
		framePayload, err := h2.readNextFrame()
		if err != nil {
			return 0, err
		}

		if len(framePayload) > 0 {
			h2.reader.Reset(framePayload)
			n, err := h2.reader.Read(p)
			h2.bytesReceived += uint64(n)
			return n, err
		}

		// Skip non-DATA frames (PING, WINDOW_UPDATE, etc.)
	}
}

// readNextFrame reads and parses the next HTTP/2 frame from the connection.
func (h2 *H2Conn) readNextFrame() ([]byte, error) {
	// Read frame header (9 bytes)
	header := make([]byte, 9)
	_, err := io.ReadFull(h2.conn, header)
	if err != nil {
		return nil, err
	}

	// Parse frame header
	length := uint32(header[0])<<16 | uint32(header[1])<<8 | uint32(header[2])
	frameType := header[3]
	flags := header[4]
	streamID := binary.BigEndian.Uint32(header[5:9]) & 0x7FFFFFFF

	// Security: limit maximum frame size
	if length > 16777215 { // 16MB
		return nil, ErrBufferOverflow
	}

	// Read frame payload
	payload := make([]byte, length)
	if length > 0 {
		_, err = io.ReadFull(h2.conn, payload)
		if err != nil {
			return nil, err
		}
	}

	// Handle different frame types
	switch frameType {
	case FrameData:
		// Handle padding
		if flags&FlagPadded != 0 && len(payload) > 0 {
			paddingLen := int(payload[0])
			if paddingLen >= len(payload) {
				return nil, ErrInvalidFrame
			}
			return payload[1 : len(payload)-paddingLen], nil
		}
		return payload, nil

	case FramePing:
		// Respond to PING frames (required by HTTP/2 spec)
		if flags&FlagAck == 0 {
			go h2.sendChromePingAck(payload)
		}
		return nil, nil

	case FrameWindowUpdate:
		// Handle window updates
		if len(payload) == 4 {
			increment := binary.BigEndian.Uint32(payload) & 0x7FFFFFFF
			h2.windowMu.Lock()
			h2.windowSize += increment
			h2.windowMu.Unlock()
		}
		return nil, nil

	case FrameSettings:
		// Acknowledge settings if needed
		if flags&FlagAck == 0 {
			go h2.sendChromeSettingsAck()
		}
		return nil, nil

	case FrameHeaders:
		// Handle headers frame (skip for tunnel)
		logrus.WithField("stream_id", streamID).Debug("Received HEADERS frame")
		return nil, nil

	case FramePriority:
		// Priority frame
		logrus.WithField("stream_id", streamID).Debug("Received PRIORITY frame")
		return nil, nil

	case FrameRSTStream:
		logrus.WithField("stream_id", streamID).Debug("Received RST_STREAM frame")
		return nil, nil

	case FrameGoAway:
		logrus.Debug("Received GOAWAY frame")
		return nil, ErrConnectionClosed

	default:
		// Skip unknown frames
		return nil, nil
	}
}

// sendChromePingAck sends a PING ACK frame matching Chrome's format.
func (h2 *H2Conn) sendChromePingAck(opaqueData []byte) {
	h2.writeMu.Lock()
	defer h2.writeMu.Unlock()

	frame := GenerateChromePingAck(opaqueData)
	h2.conn.Write(frame)
}

// sendChromeSettingsAck sends a SETTINGS ACK frame.
func (h2 *H2Conn) sendChromeSettingsAck() {
	h2.writeMu.Lock()
	defer h2.writeMu.Unlock()

	// SETTINGS ACK frame: 9 bytes header, no payload
	frame := make([]byte, 9)
	frame[3] = FrameSettings
	frame[4] = FlagAck
	h2.conn.Write(frame)
}

// SendPing sends a PING frame to keep the connection alive (Chrome style).
func (h2 *H2Conn) SendPing() error {
	h2.writeMu.Lock()
	defer h2.writeMu.Unlock()

	if h2.closed {
		return ErrConnectionClosed
	}

	frame := GenerateChromePing()
	return h2.conn.Write(frame)
}

// SendWindowUpdate sends a WINDOW_UPDATE frame (Chrome behavior).
func (h2 *H2Conn) SendWindowUpdate(streamID uint32, increment uint32) error {
	h2.writeMu.Lock()
	defer h2.writeMu.Unlock()

	if h2.closed {
		return ErrConnectionClosed
	}

	frame := GenerateChromeWindowUpdate(streamID, increment)
	return h2.conn.Write(frame)
}

// StartHeartbeat starts a goroutine that sends PING frames periodically.
// The interval is randomized to match Chrome/Facebook behavior.
func (h2 *H2Conn) StartHeartbeat(ctx context.Context, minInterval, maxInterval time.Duration) {
	go func() {
		for {
			// Calculate randomized interval (Chrome behavior)
			interval := GenerateRealisticDelay(
				int(minInterval.Milliseconds()),
				int(maxInterval.Milliseconds()),
			)

			select {
			case <-ctx.Done():
				return
			case <-time.After(interval):
				h2.closeMu.RLock()
				closed := h2.closed
				h2.closeMu.RUnlock()

				if closed {
					return
				}

				if err := h2.SendPing(); err != nil {
					logrus.WithError(err).Debug("Failed to send PING frame")
					return
				}

				// Occasionally send WINDOW_UPDATE (Chrome does this)
				if h2.rand.Float32() < 0.25 {
					increment := uint32(h2.rand.Intn(100000) + 50000)
					if err := h2.SendWindowUpdate(0, increment); err != nil {
						logrus.WithError(err).Debug("Failed to send WINDOW_UPDATE frame")
					}
				}
			}
		}
	}()
}

// Close closes the connection gracefully (Chrome-like GOAWAY).
func (h2 *H2Conn) Close() error {
	h2.closeMu.Lock()
	h2.closed = true
	h2.closeMu.Unlock()
	return h2.conn.Close()
}

// LocalAddr returns the local network address.
func (h2 *H2Conn) LocalAddr() net.Addr {
	return h2.conn.LocalAddr()
}

// RemoteAddr returns the remote network address.
func (h2 *H2Conn) RemoteAddr() net.Addr {
	return h2.conn.RemoteAddr()
}

// SetDeadline sets the read and write deadlines for the connection.
func (h2 *H2Conn) SetDeadline(t time.Time) error {
	return h2.conn.SetDeadline(t)
}

// SetReadDeadline sets the read deadline for the connection.
func (h2 *H2Conn) SetReadDeadline(t time.Time) error {
	return h2.conn.SetReadDeadline(t)
}

// SetWriteDeadline sets the write deadline for the connection.
func (h2 *H2Conn) SetWriteDeadline(t time.Time) error {
	return h2.conn.SetWriteDeadline(t)
}

// Stats returns connection statistics.
func (h2 *H2Conn) Stats() (sent, received uint64, duration time.Duration) {
	return h2.bytesSent, h2.bytesReceived, time.Since(h2.startTime)
}

// WriteSettingsFrame writes an HTTP/2 SETTINGS frame to the connection.
func WriteSettingsFrame(conn net.Conn, settings []SettingsParameter) error {
	length := len(settings) * 6

	buf := make([]byte, 9+length)

	// Write frame header
	buf[0] = byte(length >> 16)
	buf[1] = byte(length >> 8)
	buf[2] = byte(length)
	buf[3] = FrameSettings
	buf[4] = 0 // No flags for initial SETTINGS
	binary.BigEndian.PutUint32(buf[5:9], 0) // Stream ID = 0

	// Write settings
	for i, setting := range settings {
		offset := 9 + i*6
		binary.BigEndian.PutUint16(buf[offset:offset+2], setting.ID)
		binary.BigEndian.PutUint32(buf[offset+2:offset+6], setting.Value)
	}

	_, err := conn.Write(buf)
	return err
}

// WriteChromeSettings writes Chrome-exact HTTP/2 SETTINGS frame.
func WriteChromeSettings(conn net.Conn) error {
	return WriteSettingsFrame(conn, ChromeExactSettings())
}

// WriteInitialSettings writes the default Chrome-like HTTP/2 SETTINGS frame.
func WriteInitialSettings(conn net.Conn) error {
	return WriteSettingsFrame(conn, ChromeExactSettings())
}

// WriteWindowUpdate writes a WINDOW_UPDATE frame.
func WriteWindowUpdate(conn net.Conn, streamID uint32, increment uint32) error {
	frame := GenerateChromeWindowUpdate(streamID, increment)
	_, err := conn.Write(frame)
	return err
}

// WriteGoAwayFrame writes an HTTP/2 GOAWAY frame to gracefully close the connection.
func WriteGoAwayFrame(conn net.Conn, lastStreamID uint32, errorCode uint32, debugData []byte) error {
	length := 8 + len(debugData)

	buf := make([]byte, 9+length)

	buf[0] = byte(length >> 16)
	buf[1] = byte(length >> 8)
	buf[2] = byte(length)
	buf[3] = FrameGoAway
	buf[4] = 0

	binary.BigEndian.PutUint32(buf[5:9], 0)
	binary.BigEndian.PutUint32(buf[9:13], lastStreamID)
	binary.BigEndian.PutUint32(buf[13:17], errorCode)

	if len(debugData) > 0 {
		copy(buf[17:], debugData)
	}

	_, err := conn.Write(buf)
	return err
}

// WritePriorityFrame writes a PRIORITY frame.
func WritePriorityFrame(conn net.Conn, streamID uint32, priority StreamPriority) error {
	buf := make([]byte, 14)

	// Frame header
	buf[2] = 5 // Length
	buf[3] = FramePriority
	buf[4] = FlagEndHeaders
	binary.BigEndian.PutUint32(buf[5:9], streamID)

	// Priority payload
	copy(buf[9:14], EncodePriority(priority))

	_, err := conn.Write(buf)
	return err
}

// WriteSettingsAck writes a SETTINGS ACK frame.
func WriteSettingsAck(conn net.Conn) error {
	frame := make([]byte, 9)
	frame[3] = FrameSettings
	frame[4] = FlagAck
	_, err := conn.Write(frame)
	return err
}
