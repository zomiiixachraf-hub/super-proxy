// Package core provides metrics collection for the FaceMimic protocol.
package core

import (
	"fmt"
	"runtime"
	"sync"
	"sync/atomic"
	"time"
)

// Metrics holds operational metrics for the FaceMimic system.
type Metrics struct {
	// Connection metrics
	TotalConnections   uint64 // Total connections accepted
	ActiveConnections  uint64 // Currently active connections
	FailedConnections  uint64 // Failed connection attempts
	RejectedProbes     uint64 // Detected and rejected probes
	AuthSuccesses      uint64 // Successful authentications
	AuthFailures       uint64 // Failed authentication attempts

	// Traffic metrics
	BytesSent          uint64 // Total bytes sent
	BytesReceived      uint64 // Total bytes received
	StreamsOpened      uint64 // Total streams opened
	StreamsClosed      uint64 // Total streams closed

	// Timing metrics
	TotalHandshakeTime uint64 // Cumulative handshake time (nanoseconds)
	TotalConnectionTime uint64 // Cumulative connection duration (nanoseconds)

	// Cache metrics
	ReplayCacheHits    uint64 // Replay cache hits (blocked)
	ReplayCacheMisses  uint64 // Replay cache misses (allowed)

	// Error metrics
	TLSErrors          uint64 // TLS handshake errors
	NetworkErrors      uint64 // Network I/O errors
	TimeoutErrors      uint64 // Timeout errors

	// Internal state
	startTime          time.Time
	lastUpdate         time.Time
	mu                 sync.RWMutex
}

// NewMetrics creates a new Metrics instance.
func NewMetrics() *Metrics {
	return &Metrics{
		startTime:  time.Now(),
		lastUpdate: time.Now(),
	}
}

// Increment atomically increments a counter by 1.
func (m *Metrics) Increment(counter *uint64) {
	atomic.AddUint64(counter, 1)
}

// Add atomically adds a value to a counter.
func (m *Metrics) Add(counter *uint64, value uint64) {
	atomic.AddUint64(counter, value)
}

// Get atomically reads a counter value.
func (m *Metrics) Get(counter *uint64) uint64 {
	return atomic.LoadUint64(counter)
}

// RecordConnection increments the connection counter.
func (m *Metrics) RecordConnection() {
	m.Increment(&m.TotalConnections)
}

// RecordActiveConnection adds to active connection count.
func (m *Metrics) RecordActiveConnection(delta int64) {
	if delta > 0 {
		atomic.AddUint64(&m.ActiveConnections, uint64(delta))
	} else {
		// Atomic subtract for negative delta
		for {
			old := atomic.LoadUint64(&m.ActiveConnections)
			newVal := old - uint64(-delta)
			if atomic.CompareAndSwapUint64(&m.ActiveConnections, old, newVal) {
				break
			}
		}
	}
}

// RecordFailedConnection increments the failed connection counter.
func (m *Metrics) RecordFailedConnection() {
	m.Increment(&m.FailedConnections)
}

// RecordProbe increments the probe counter.
func (m *Metrics) RecordProbe() {
	m.Increment(&m.RejectedProbes)
}

// RecordAuth increments authentication counters.
func (m *Metrics) RecordAuth(success bool) {
	if success {
		m.Increment(&m.AuthSuccesses)
	} else {
		m.Increment(&m.AuthFailures)
	}
}

// RecordTraffic records bytes transferred.
func (m *Metrics) RecordTraffic(sent, received uint64) {
	if sent > 0 {
		m.Add(&m.BytesSent, sent)
	}
	if received > 0 {
		m.Add(&m.BytesReceived, received)
	}
}

// RecordStream records stream operations.
func (m *Metrics) RecordStream(opened bool) {
	if opened {
		m.Increment(&m.StreamsOpened)
	} else {
		m.Increment(&m.StreamsClosed)
	}
}

// RecordHandshake records handshake timing.
func (m *Metrics) RecordHandshake(duration time.Duration) {
	m.Add(&m.TotalHandshakeTime, uint64(duration.Nanoseconds()))
}

// RecordConnectionDuration records total connection duration.
func (m *Metrics) RecordConnectionDuration(duration time.Duration) {
	m.Add(&m.TotalConnectionTime, uint64(duration.Nanoseconds()))
}

// RecordReplayCache records replay cache operations.
func (m *Metrics) RecordReplayCache(hit bool) {
	if hit {
		m.Increment(&m.ReplayCacheHits)
	} else {
		m.Increment(&m.ReplayCacheMisses)
	}
}

// RecordError records error types.
func (m *Metrics) RecordError(errorType string) {
	switch errorType {
	case "tls":
		m.Increment(&m.TLSErrors)
	case "network":
		m.Increment(&m.NetworkErrors)
	case "timeout":
		m.Increment(&m.TimeoutErrors)
	}
}

// Snapshot returns a point-in-time snapshot of all metrics.
func (m *Metrics) Snapshot() MetricsSnapshot {
	return MetricsSnapshot{
		Timestamp:           time.Now(),
		Uptime:             time.Since(m.startTime),
		TotalConnections:   m.Get(&m.TotalConnections),
		ActiveConnections:  m.Get(&m.ActiveConnections),
		FailedConnections:  m.Get(&m.FailedConnections),
		RejectedProbes:     m.Get(&m.RejectedProbes),
		AuthSuccesses:      m.Get(&m.AuthSuccesses),
		AuthFailures:       m.Get(&m.AuthFailures),
		BytesSent:          m.Get(&m.BytesSent),
		BytesReceived:      m.Get(&m.BytesReceived),
		StreamsOpened:      m.Get(&m.StreamsOpened),
		StreamsClosed:      m.Get(&m.StreamsClosed),
		ReplayCacheHits:    m.Get(&m.ReplayCacheHits),
		ReplayCacheMisses:  m.Get(&m.ReplayCacheMisses),
		TLSErrors:          m.Get(&m.TLSErrors),
		NetworkErrors:      m.Get(&m.NetworkErrors),
		TimeoutErrors:      m.Get(&m.TimeoutErrors),
	}
}

// MetricsSnapshot is a point-in-time snapshot of metrics.
type MetricsSnapshot struct {
	Timestamp          time.Time     `json:"timestamp"`
	Uptime             time.Duration `json:"uptime"`
	TotalConnections   uint64        `json:"total_connections"`
	ActiveConnections  uint64        `json:"active_connections"`
	FailedConnections  uint64        `json:"failed_connections"`
	RejectedProbes     uint64        `json:"rejected_probes"`
	AuthSuccesses      uint64        `json:"auth_successes"`
	AuthFailures       uint64        `json:"auth_failures"`
	BytesSent          uint64        `json:"bytes_sent"`
	BytesReceived      uint64        `json:"bytes_received"`
	StreamsOpened      uint64        `json:"streams_opened"`
	StreamsClosed      uint64        `json:"streams_closed"`
	ReplayCacheHits    uint64        `json:"replay_cache_hits"`
	ReplayCacheMisses  uint64        `json:"replay_cache_misses"`
	TLSErrors          uint64        `json:"tls_errors"`
	NetworkErrors      uint64        `json:"network_errors"`
	TimeoutErrors      uint64        `json:"timeout_errors"`
}

// String returns a formatted string representation.
func (s MetricsSnapshot) String() string {
	return fmt.Sprintf(
		"Metrics[uptime=%s, conns=%d(active=%d,failed=%d), probes=%d, auth=%d/%d, traffic=%s↑/%s↓, streams=%d/%d, errors=(tls:%d,net:%d,timeout:%d)]",
		s.Uptime.Round(time.Second),
		s.TotalConnections, s.ActiveConnections, s.FailedConnections,
		s.RejectedProbes,
		s.AuthSuccesses, s.AuthFailures,
		FormatBytes(s.BytesSent), FormatBytes(s.BytesReceived),
		s.StreamsOpened, s.StreamsClosed,
		s.TLSErrors, s.NetworkErrors, s.TimeoutErrors,
	)
}

// ToMap returns metrics as a map for JSON serialization.
func (s MetricsSnapshot) ToMap() map[string]interface{} {
	return map[string]interface{}{
		"timestamp":          s.Timestamp.Format(time.RFC3339),
		"uptime_seconds":     s.Uptime.Seconds(),
		"total_connections":  s.TotalConnections,
		"active_connections": s.ActiveConnections,
		"failed_connections": s.FailedConnections,
		"rejected_probes":    s.RejectedProbes,
		"auth_successes":     s.AuthSuccesses,
		"auth_failures":      s.AuthFailures,
		"bytes_sent":         s.BytesSent,
		"bytes_received":     s.BytesReceived,
		"streams_opened":     s.StreamsOpened,
		"streams_closed":     s.StreamsClosed,
		"replay_cache_hits":  s.ReplayCacheHits,
		"replay_cache_misses": s.ReplayCacheMisses,
		"tls_errors":         s.TLSErrors,
		"network_errors":     s.NetworkErrors,
		"timeout_errors":     s.TimeoutErrors,
	}
}

// ThroughputStats calculates throughput statistics.
func (s MetricsSnapshot) ThroughputStats() (sendRate, recvRate float64) {
	uptimeSeconds := s.Uptime.Seconds()
	if uptimeSeconds > 0 {
		sendRate = float64(s.BytesSent) / uptimeSeconds
		recvRate = float64(s.BytesReceived) / uptimeSeconds
	}
	return
}

// SuccessRate calculates the authentication success rate.
func (s MetricsSnapshot) SuccessRate() float64 {
	total := s.AuthSuccesses + s.AuthFailures
	if total == 0 {
		return 0
	}
	return float64(s.AuthSuccesses) / float64(total) * 100
}

// FormatBytes formats bytes into human-readable format.
func FormatBytes(bytes uint64) string {
	const unit = 1024
	if bytes < unit {
		return fmt.Sprintf("%d B", bytes)
	}
	div, exp := uint64(unit), 0
	for n := bytes / unit; n >= unit; n /= unit {
		div *= unit
		exp++
	}
	return fmt.Sprintf("%.1f %ciB", float64(bytes)/float64(div), "KMGTPE"[exp])
}

// FormatDuration formats duration into human-readable format.
func FormatDuration(d time.Duration) string {
	if d < time.Second {
		return fmt.Sprintf("%dms", d.Milliseconds())
	}
	if d < time.Minute {
		return fmt.Sprintf("%.1fs", d.Seconds())
	}
	if d < time.Hour {
		return fmt.Sprintf("%.1fm", d.Minutes())
	}
	return fmt.Sprintf("%.1fh", d.Hours())
}

// GlobalMetrics is the global metrics instance.
var GlobalMetrics = NewMetrics()

// RuntimeStats holds runtime statistics.
type RuntimeStats struct {
	Goroutines     int           `json:"goroutines"`
	CPUCount       int           `json:"cpu_count"`
	MemAllocMB     float64       `json:"mem_alloc_mb"`
	MemTotalMB     float64       `json:"mem_total_mb"`
	MemSysMB       float64       `json:"mem_sys_mb"`
	NumGC          uint32        `json:"num_gc"`
	GoroutineDelta int           `json:"goroutine_delta"`
	LastGC         time.Time     `json:"last_gc"`
}

// GetRuntimeStats returns current runtime statistics.
func GetRuntimeStats() RuntimeStats {
	var m runtime.MemStats
	runtime.ReadMemStats(&m)

	return RuntimeStats{
		Goroutines: runtime.NumGoroutine(),
		CPUCount:   runtime.NumCPU(),
		MemAllocMB: float64(m.Alloc) / 1024 / 1024,
		MemTotalMB: float64(m.TotalAlloc) / 1024 / 1024,
		MemSysMB:   float64(m.Sys) / 1024 / 1024,
		NumGC:      m.NumGC,
		LastGC:     time.Unix(0, int64(m.LastGC)),
	}
}

// HealthStatus represents the health status of the system.
type HealthStatus struct {
	Status       string            `json:"status"`       // "healthy", "degraded", "unhealthy"
	Uptime       time.Duration     `json:"uptime"`
	Metrics      MetricsSnapshot   `json:"metrics"`
	Runtime      RuntimeStats      `json:"runtime"`
	Checks       map[string]string `json:"checks"`
}

// CheckHealth performs health checks and returns status.
func CheckHealth() HealthStatus {
	snapshot := GlobalMetrics.Snapshot()
	runtime := GetRuntimeStats()

	status := "healthy"
	checks := make(map[string]string)

	// Check memory usage
	if runtime.MemSysMB > 1024 { // > 1GB
		status = "degraded"
		checks["memory"] = "high_memory_usage"
	} else {
		checks["memory"] = "ok"
	}

	// Check goroutine count
	if runtime.Goroutines > 10000 {
		status = "degraded"
		checks["goroutines"] = "high_goroutine_count"
	} else {
		checks["goroutines"] = "ok"
	}

	// Check error rate
	if snapshot.AuthFailures > 0 {
		errorRate := float64(snapshot.AuthFailures) / float64(snapshot.AuthSuccesses+snapshot.AuthFailures)
		if errorRate > 0.5 { // > 50% failure rate
			status = "degraded"
			checks["auth"] = "high_failure_rate"
		} else {
			checks["auth"] = "ok"
		}
	} else {
		checks["auth"] = "ok"
	}

	return HealthStatus{
		Status:  status,
		Uptime:  snapshot.Uptime,
		Metrics: snapshot,
		Runtime: runtime,
		Checks:  checks,
	}
}
