// Package core provides the cryptographic primitives and authentication mechanisms
// for the FaceMimic tunneling protocol. This module implements the "Phantom Identity"
// handshake using TLS SessionID steganography.
package core

import (
	"crypto/hmac"
	"crypto/sha256"
	"encoding/hex"
	"fmt"
	"sync"
	"time"

	"github.com/sirupsen/logrus"
)

const (
	// TimeDriftSeconds defines the acceptable time window for authentication.
	// This accounts for clock skew between client and server.
	// The client will try t, t-1, t+1, t-2, t+2, etc. up to this bound.
	TimeDriftSeconds = 30

	// SessionIDLength is the length of a TLS SessionID in bytes.
	// The TLS 1.2 specification defines this as exactly 32 bytes.
	SessionIDLength = 32

	// ReplayCacheCleanupInterval is how often the replay cache garbage collector runs.
	ReplayCacheCleanupInterval = 60 * time.Second
)

// ReplayCache provides thread-safe storage for detecting replay attacks.
// It uses a sync.Map for high concurrency scenarios with minimal lock contention.
// Each entry stores the timestamp when the SessionID was first seen.
type ReplayCache struct {
	// entries holds the SessionID -> timestamp mapping.
	// Key: hex-encoded SessionID string
	// Value: Unix timestamp when the entry was created
	entries sync.Map

	// mu protects the size tracking and cleanup operations
	mu sync.RWMutex

	// size tracks the approximate number of entries for memory management
	size int

	// maxSize is the maximum number of entries before forced cleanup
	maxSize int

	// stopCh signals the background garbage collector to stop
	stopCh chan struct{}

	// wg tracks background goroutines for graceful shutdown
	wg sync.WaitGroup
}

// replayEntry represents a stored entry in the replay cache.
type replayEntry struct {
	Timestamp int64
	Seen      time.Time
}

// NewReplayCache creates a new ReplayCache with the specified maximum size.
// It starts a background garbage collector that removes expired entries.
func NewReplayCache(maxSize int) *ReplayCache {
	rc := &ReplayCache{
		maxSize: maxSize,
		stopCh:  make(chan struct{}),
	}

	// Start background garbage collector
	rc.wg.Add(1)
	go rc.gc()

	return rc
}

// Close stops the background garbage collector and releases resources.
func (rc *ReplayCache) Close() {
	close(rc.stopCh)
	rc.wg.Wait()
}

// gc is the background garbage collector that removes expired entries.
// It runs every ReplayCacheCleanupInterval and removes entries older than
// TimeDriftSeconds from the current time.
func (rc *ReplayCache) gc() {
	defer rc.wg.Done()

	ticker := time.NewTicker(ReplayCacheCleanupInterval)
	defer ticker.Stop()

	for {
		select {
		case <-rc.stopCh:
			return
		case <-ticker.C:
			rc.cleanup()
		}
	}
}

// cleanup removes expired entries from the cache.
// This prevents unbounded memory growth while maintaining security.
func (rc *ReplayCache) cleanup() {
	now := time.Now().Unix()
	var removed int

	rc.entries.Range(func(key, value interface{}) bool {
		entry, ok := value.(replayEntry)
		if !ok {
			rc.entries.Delete(key)
			return true
		}

		// Remove entries older than the time drift window
		if now-entry.Timestamp > TimeDriftSeconds {
			rc.entries.Delete(key)
			rc.mu.Lock()
			if rc.size > 0 {
				rc.size--
			}
			rc.mu.Unlock()
			removed++
		}
		return true
	})

	if removed > 0 {
		logrus.WithField("removed", removed).Debug("ReplayCache cleanup completed")
	}
}

// CheckAndStore checks if a SessionID has been seen before and stores it if new.
// Returns true if the SessionID is valid (not a replay), false if it's a duplicate.
// This operation is atomic to prevent race conditions in high-concurrency scenarios.
func (rc *ReplayCache) CheckAndStore(sessionID []byte, timestamp int64) bool {
	key := hex.EncodeToString(sessionID)
	entry := replayEntry{
		Timestamp: timestamp,
		Seen:      time.Now(),
	}

	// Check if entry already exists
	if _, exists := rc.entries.Load(key); exists {
		logrus.WithField("session_id", key[:16]+"...").Warn("Replay attack detected")
		return false
	}

	// Check size limit
	rc.mu.RLock()
	if rc.size >= rc.maxSize {
		rc.mu.RUnlock()
		// Force cleanup if at capacity
		rc.cleanup()
		rc.mu.RLock()
	}
	rc.mu.RUnlock()

	// Store the entry
	actual, loaded := rc.entries.LoadOrStore(key, entry)
	if loaded {
		// Another goroutine stored it first
		if existing, ok := actual.(replayEntry); ok {
			logrus.WithFields(logrus.Fields{
				"session_id":      key[:16] + "...",
				"original_time":   existing.Timestamp,
				"attempted_time":  timestamp,
				"time_difference": timestamp - existing.Timestamp,
			}).Warn("Concurrent replay detected")
		}
		return false
	}

	rc.mu.Lock()
	rc.size++
	rc.mu.Unlock()

	return true
}

// GenerateSessionID creates a cryptographically authentic SessionID for the given timestamp.
// The SessionID appears random to network observers but can be validated by the server.
//
// The algorithm uses HMAC-SHA256 with the pre-shared secret:
//   SessionID = HMAC-SHA256(PreSharedKey, CurrentUnixTimestamp)
//
// The output is truncated to 32 bytes to fit the TLS SessionID field.
func GenerateSessionID(timestamp int64, secret string) []byte {
	h := hmac.New(sha256.New, []byte(secret))

	// Write the timestamp as a fixed-width integer for consistent encoding
	timestampBytes := []byte(fmt.Sprintf("%d", timestamp))
	h.Write(timestampBytes)

	// The HMAC output is 32 bytes (SHA256), perfect for TLS SessionID
	return h.Sum(nil)
}

// ValidateSessionID verifies if a SessionID is authentic and within the valid time window.
// It returns:
//   - valid: true if the SessionID is authentic and not expired
//   - timestamp: the timestamp extracted from the SessionID
//   - drift: the time difference between the SessionID timestamp and current time
//
// The function checks all possible timestamps within TimeDriftSeconds of the current time
// to account for clock skew between client and server.
func ValidateSessionID(sessionID []byte, secret string) (valid bool, timestamp int64, drift int64) {
	if len(sessionID) != SessionIDLength {
		logrus.WithField("length", len(sessionID)).Debug("Invalid SessionID length")
		return false, 0, 0
	}

	now := time.Now().Unix()

	// Check all possible timestamps within the drift window
	// Start from the current time and expand outward
	for offset := int64(0); offset <= TimeDriftSeconds; offset++ {
		// Check current time + offset
		if check, ts := validateAtTime(sessionID, secret, now+offset); check {
			return true, ts, offset
		}

		// Check current time - offset (only if offset > 0 to avoid double-checking)
		if offset > 0 {
			if check, ts := validateAtTime(sessionID, secret, now-offset); check {
				return true, ts, -offset
			}
		}
	}

	return false, 0, 0
}

// validateAtTime checks if the SessionID is valid for a specific timestamp.
func validateAtTime(sessionID []byte, secret string, timestamp int64) (bool, int64) {
	expected := GenerateSessionID(timestamp, secret)
	if hmac.Equal(sessionID, expected) {
		return true, timestamp
	}
	return false, 0
}

// GenerateTimeWindowSessionIDs generates all valid SessionIDs for the current time window.
// This is useful for the client to try multiple timestamps during authentication.
func GenerateTimeWindowSessionIDs(secret string) map[int64][]byte {
	now := time.Now().Unix()
	result := make(map[int64][]byte)

	for offset := int64(-TimeDriftSeconds); offset <= TimeDriftSeconds; offset++ {
		ts := now + offset
		result[ts] = GenerateSessionID(ts, secret)
	}

	return result
}

// ExtractSessionIDFromClientHello extracts the SessionID from a TLS ClientHello message.
// Returns nil if the data is not a valid ClientHello or doesn't contain a SessionID.
//
// TLS ClientHello structure:
//   - Byte 0: Handshake type (0x01 for ClientHello)
//   - Bytes 1-3: Handshake length
//   - Bytes 4-5: Client version
//   - Bytes 6-37: Client random (32 bytes)
//   - Byte 38: Session ID length
//   - Bytes 39+: Session ID (variable length, up to 32 bytes)
func ExtractSessionIDFromClientHello(data []byte) []byte {
	// Minimum ClientHello size check
	if len(data) < 39 {
		return nil
	}

	// Check if this is a ClientHello (handshake type 0x01)
	// Note: The record layer wraps this, so we need to check the content type first
	// TLS Record: content_type (1) | version (2) | length (2) | payload
	// We expect content_type = 0x16 (handshake) and handshake_type = 0x01 (ClientHello)

	// Check for TLS record header
	if len(data) >= 5 && data[0] == 0x16 {
		// Skip TLS record header (5 bytes)
		recordPayload := data[5:]
		if len(recordPayload) < 39 {
			return nil
		}

		// Check handshake type
		if recordPayload[0] != 0x01 {
			return nil
		}

		// Skip: handshake type (1) + length (3) + client version (2) + client random (32)
		// = 38 bytes to get to session ID length
		sessionIDLength := int(recordPayload[38])
		if sessionIDLength == 0 || sessionIDLength > 32 {
			return nil
		}

		// Check if we have enough data
		if len(recordPayload) < 39+sessionIDLength {
			return nil
		}

		sessionID := recordPayload[39 : 39+sessionIDLength]
		return sessionID
	}

	// Direct ClientHello (no TLS record wrapper) - less common but handle it
	if data[0] == 0x01 {
		sessionIDLength := int(data[38])
		if sessionIDLength == 0 || sessionIDLength > 32 {
			return nil
		}

		if len(data) < 39+sessionIDLength {
			return nil
		}

		return data[39 : 39+sessionIDLength]
	}

	return nil
}

// ConstantTimeCompare performs a constant-time comparison of two byte slices.
// This prevents timing attacks when comparing authentication tokens.
func ConstantTimeCompare(a, b []byte) bool {
	return hmac.Equal(a, b)
}

// DeriveKey derives a session-specific key from the master secret and session context.
// This can be used for additional encryption layers if desired.
func DeriveKey(masterSecret, context []byte, length int) []byte {
	h := hmac.New(sha256.New, masterSecret)
	h.Write(context)
	result := h.Sum(nil)

	if length > len(result) {
		// Extend using HKDF-like expansion
		extended := make([]byte, length)
		copy(extended, result)

		// Simple extension for cases needing more bytes
		for i := len(result); i < length; i++ {
			h.Reset()
			h.Write(result)
			h.Write([]byte{byte(i)})
			result = h.Sum(nil)
			extended[i] = result[0]
		}
		return extended
	}

	return result[:length]
}

// Authenticator provides a high-level interface for authentication operations.
// It encapsulates the secret and replay cache for simplified usage.
type Authenticator struct {
	secret string
	cache  *ReplayCache
}

// NewAuthenticator creates a new Authenticator with the given secret.
func NewAuthenticator(secret string, cacheSize int) *Authenticator {
	return &Authenticator{
		secret: secret,
		cache:  NewReplayCache(cacheSize),
	}
}

// Close releases resources held by the Authenticator.
func (a *Authenticator) Close() {
	a.cache.Close()
}

// GenerateSessionID creates a new authentic SessionID for the current time.
func (a *Authenticator) GenerateSessionID() []byte {
	return GenerateSessionID(time.Now().Unix(), a.secret)
}

// Authenticate validates a SessionID and checks for replay attacks.
// Returns true only if the SessionID is valid and hasn't been used before.
func (a *Authenticator) Authenticate(sessionID []byte) (bool, int64) {
	valid, timestamp, _ := ValidateSessionID(sessionID, a.secret)
	if !valid {
		return false, 0
	}

	// Check for replay attacks
	if !a.cache.CheckAndStore(sessionID, timestamp) {
		return false, 0
	}

	return true, timestamp
}

// AuthenticateWithDrift validates a SessionID and returns the time drift.
// This is useful for logging and monitoring clock synchronization.
func (a *Authenticator) AuthenticateWithDrift(sessionID []byte) (bool, int64, int64) {
	valid, timestamp, drift := ValidateSessionID(sessionID, a.secret)
	if !valid {
		return false, 0, 0
	}

	// Check for replay attacks
	if !a.cache.CheckAndStore(sessionID, timestamp) {
		return false, 0, 0
	}

	return true, timestamp, drift
}
