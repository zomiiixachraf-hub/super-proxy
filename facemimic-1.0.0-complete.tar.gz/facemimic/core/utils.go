// Package core provides utility functions for the FaceMimic protocol.
package core

import (
	"crypto/rand"
	"encoding/hex"
	"fmt"
	"io"
	"math/big"
	"net"
	"os"
	"runtime"
	"strings"
	"sync"
	"time"

	"github.com/sirupsen/logrus"
)

// RandomBytes generates cryptographically secure random bytes.
func RandomBytes(n int) ([]byte, error) {
	b := make([]byte, n)
	_, err := rand.Read(b)
	if err != nil {
		return nil, fmt.Errorf("failed to generate random bytes: %w", err)
	}
	return b, nil
}

// RandomHexString generates a random hex-encoded string of the specified length.
func RandomHexString(length int) (string, error) {
	bytes, err := RandomBytes(length / 2)
	if err != nil {
		return "", err
	}
	return hex.EncodeToString(bytes), nil
}

// RandomDuration returns a random duration between min and max.
func RandomDuration(min, max time.Duration) time.Duration {
	if min >= max {
		return min
	}
	diff := max - min
	n, _ := rand.Int(rand.Reader, big.NewInt(int64(diff)))
	return min + time.Duration(n.Int64())
}

// IsIPv4 checks if an IP address is IPv4.
func IsIPv4(ip net.IP) bool {
	return ip.To4() != nil
}

// IsIPv6 checks if an IP address is IPv6.
func IsIPv6(ip net.IP) bool {
	return ip.To4() == nil && ip.To16() != nil
}

// ParseIPPort parses an address string in the format "IP:Port".
func ParseIPPort(addr string) (net.IP, int, error) {
	host, portStr, err := net.SplitHostPort(addr)
	if err != nil {
		return nil, 0, fmt.Errorf("invalid address format: %w", err)
	}

	ip := net.ParseIP(host)
	if ip == nil {
		return nil, 0, fmt.Errorf("invalid IP address: %s", host)
	}

	port := 0
	_, err = fmt.Sscanf(portStr, "%d", &port)
	if err != nil {
		return nil, 0, fmt.Errorf("invalid port: %s", portStr)
	}

	return ip, port, nil
}

// GetOutboundIP returns the preferred outbound IP for connecting to a target.
func GetOutboundIP(targetAddr string) (net.IP, error) {
	conn, err := net.Dial("udp", targetAddr)
	if err != nil {
		return nil, fmt.Errorf("failed to determine outbound IP: %w", err)
	}
	defer conn.Close()

	localAddr := conn.LocalAddr().(*net.UDPAddr)
	return localAddr.IP, nil
}

// CopyResult holds the result of a copy operation.
type CopyResult struct {
	Bytes    uint64
	Duration time.Duration
	Error    error
	RateBps  float64
}

// CopyWithProgress copies data with periodic progress callbacks.
func CopyWithProgress(dst io.Writer, src io.Reader, interval time.Duration, callback func(bytes uint64)) (uint64, error) {
	buf := make([]byte, 32*1024) // 32KB buffer
	var total uint64
	var lastReport time.Time = time.Now()

	for {
		n, err := src.Read(buf)
		if n > 0 {
			written, writeErr := dst.Write(buf[:n])
			total += uint64(written)
			if writeErr != nil {
				return total, writeErr
			}
			if written != n {
				return total, io.ErrShortWrite
			}

			// Progress callback
			if callback != nil && time.Since(lastReport) >= interval {
				callback(total)
				lastReport = time.Now()
			}
		}
		if err != nil {
			if err == io.EOF {
				return total, nil
			}
			return total, err
		}
	}
}

// RateLimiter implements a simple token bucket rate limiter.
type RateLimiter struct {
	rate      int64 // bytes per second
	tokens    int64 // current tokens
	maxTokens int64 // maximum tokens
	mu        sync.Mutex
	lastTime  time.Time
}

// NewRateLimiter creates a new rate limiter with the specified rate (bytes/second).
func NewRateLimiter(rate int64) *RateLimiter {
	return &RateLimiter{
		rate:      rate,
		tokens:    rate,
		maxTokens: rate,
		lastTime:  time.Now(),
	}
}

// Allow checks if n bytes can be transferred, blocking if necessary.
func (rl *RateLimiter) Allow(n int64) time.Duration {
	rl.mu.Lock()
	defer rl.mu.Unlock()

	now := time.Now()
	elapsed := now.Sub(rl.lastTime)
	rl.lastTime = now

	// Add tokens based on elapsed time
	rl.tokens += int64(elapsed.Seconds() * float64(rl.rate))
	if rl.tokens > rl.maxTokens {
		rl.tokens = rl.maxTokens
	}

	if rl.tokens >= n {
		rl.tokens -= n
		return 0
	}

	// Calculate wait time
	needed := n - rl.tokens
	waitTime := time.Duration(float64(needed) / float64(rl.rate) * float64(time.Second))
	return waitTime
}

// SetRate updates the rate limit.
func (rl *RateLimiter) SetRate(rate int64) {
	rl.mu.Lock()
	defer rl.mu.Unlock()
	rl.rate = rate
	rl.maxTokens = rate
	if rl.tokens > rl.maxTokens {
		rl.tokens = rl.maxTokens
	}
}

// ByteCounter tracks bytes transferred.
type ByteCounter struct {
	count uint64
	mu    sync.RWMutex
}

// Add increments the counter by n bytes.
func (bc *ByteCounter) Add(n uint64) {
	bc.mu.Lock()
	defer bc.mu.Unlock()
	bc.count += n
}

// Count returns the current count.
func (bc *ByteCounter) Count() uint64 {
	bc.mu.RLock()
	defer bc.mu.RUnlock()
	return bc.count
}

// Reset resets the counter to zero.
func (bc *ByteCounter) Reset() {
	bc.mu.Lock()
	defer bc.mu.Unlock()
	bc.count = 0
}

// Write implements io.Writer for counting bytes.
func (bc *ByteCounter) Write(p []byte) (int, error) {
	bc.Add(uint64(len(p)))
	return len(p), nil
}

// MemoryPool provides a pool of reusable byte buffers.
type MemoryPool struct {
	pool    sync.Pool
	bufSize int
}

// NewMemoryPool creates a new memory pool with the specified buffer size.
func NewMemoryPool(bufSize int) *MemoryPool {
	return &MemoryPool{
		bufSize: bufSize,
		pool: sync.Pool{
			New: func() interface{} {
				return make([]byte, bufSize)
			},
		},
	}
}

// Get retrieves a buffer from the pool.
func (mp *MemoryPool) Get() []byte {
	return mp.pool.Get().([]byte)
}

// Put returns a buffer to the pool.
func (mp *MemoryPool) Put(buf []byte) {
	if len(buf) == mp.bufSize {
		mp.pool.Put(buf)
	}
}

// SystemInfo holds system information.
type SystemInfo struct {
	GoVersion      string
	OS             string
	Arch           string
	CPUCount       int
	GoroutineCount int
	MemStats       runtime.MemStats
}

// GetSystemInfo returns current system information.
func GetSystemInfo() SystemInfo {
	var m runtime.MemStats
	runtime.ReadMemStats(&m)

	return SystemInfo{
		GoVersion:      runtime.Version(),
		OS:             runtime.GOOS,
		Arch:           runtime.GOARCH,
		CPUCount:       runtime.NumCPU(),
		GoroutineCount: runtime.NumGoroutine(),
		MemStats:       m,
	}
}

// LogSystemInfo logs system information.
func LogSystemInfo() {
	info := GetSystemInfo()
	logrus.WithFields(logrus.Fields{
		"go_version": info.GoVersion,
		"os":         info.OS,
		"arch":       info.Arch,
		"cpu_count":  info.CPUCount,
		"goroutines": info.GoroutineCount,
		"heap_alloc": info.MemStats.HeapAlloc,
		"sys_mem":    info.MemStats.Sys,
		"num_gc":     info.MemStats.NumGC,
	}).Info("System information")
}

// FileExists checks if a file exists.
func FileExists(path string) bool {
	_, err := os.Stat(path)
	return !os.IsNotExist(err)
}

// EnsureDir creates a directory if it doesn't exist.
func EnsureDir(path string) error {
	if !FileExists(path) {
		return os.MkdirAll(path, 0755)
	}
	return nil
}

// CleanupDir removes old files from a directory based on age.
func CleanupDir(dir string, maxAge time.Duration) error {
	entries, err := os.ReadDir(dir)
	if err != nil {
		return err
	}

	cutoff := time.Now().Add(-maxAge)
	for _, entry := range entries {
		info, err := entry.Info()
		if err != nil {
			continue
		}
		if info.ModTime().Before(cutoff) {
			os.Remove(dir + "/" + entry.Name())
			logrus.WithField("file", entry.Name()).Debug("Cleaned up old file")
		}
	}
	return nil
}

// MaskIP masks parts of an IP address for logging.
func MaskIP(ip net.IP) string {
	if ip.To4() != nil {
		// IPv4: mask last octet
		parts := strings.Split(ip.String(), ".")
		if len(parts) == 4 {
			return fmt.Sprintf("%s.%s.%s.xxx", parts[0], parts[1], parts[2])
		}
	}
	// IPv6: show only first segment
	parts := strings.Split(ip.String(), ":")
	if len(parts) > 2 {
		return parts[0] + ":" + parts[1] + ":xxxx:..."
	}
	return ip.String()
}

// MaskPort masks a port number for logging.
func MaskPort(port int) string {
	if port < 1000 {
		return "****"
	}
	return fmt.Sprintf("%d**", port/100)
}

// SafeClose safely closes an io.Closer and logs any error.
func SafeClose(closer io.Closer, name string) {
	if closer != nil {
		if err := closer.Close(); err != nil {
			logrus.WithError(err).WithField("resource", name).Debug("Error closing resource")
		}
	}
}

// Retry executes a function with retry logic.
func Retry(fn func() error, maxAttempts int, delay time.Duration, backoff float64) error {
	var lastErr error
	currentDelay := delay

	for i := 0; i < maxAttempts; i++ {
		err := fn()
		if err == nil {
			return nil
		}
		lastErr = err

		if i < maxAttempts-1 {
			logrus.WithError(err).WithField("attempt", i+1).Debug("Operation failed, retrying...")
			time.Sleep(currentDelay)
			currentDelay = time.Duration(float64(currentDelay) * backoff)
		}
	}

	return fmt.Errorf("operation failed after %d attempts: %w", maxAttempts, lastErr)
}

// Timeout executes a function with a timeout.
func Timeout(fn func() error, timeout time.Duration) error {
	done := make(chan error, 1)

	go func() {
		done <- fn()
	}()

	select {
	case err := <-done:
		return err
	case <-time.After(timeout):
		return fmt.Errorf("operation timed out after %v", timeout)
	}
}

// ConnTracker tracks active connections.
type ConnTracker struct {
	conns map[string]time.Time
	mu    sync.RWMutex
}

// NewConnTracker creates a new connection tracker.
func NewConnTracker() *ConnTracker {
	return &ConnTracker{
		conns: make(map[string]time.Time),
	}
}

// Add adds a connection to the tracker.
func (ct *ConnTracker) Add(id string) {
	ct.mu.Lock()
	defer ct.mu.Unlock()
	ct.conns[id] = time.Now()
}

// Remove removes a connection from the tracker.
func (ct *ConnTracker) Remove(id string) {
	ct.mu.Lock()
	defer ct.mu.Unlock()
	delete(ct.conns, id)
}

// Count returns the number of active connections.
func (ct *ConnTracker) Count() int {
	ct.mu.RLock()
	defer ct.mu.RUnlock()
	return len(ct.conns)
}

// List returns a list of active connection IDs.
func (ct *ConnTracker) List() []string {
	ct.mu.RLock()
	defer ct.mu.RUnlock()

	ids := make([]string, 0, len(ct.conns))
	for id := range ct.conns {
		ids = append(ids, id)
	}
	return ids
}

// Cleanup removes connections older than maxAge.
func (ct *ConnTracker) Cleanup(maxAge time.Duration) int {
	ct.mu.Lock()
	defer ct.mu.Unlock()

	cutoff := time.Now().Add(-maxAge)
	var removed int

	for id, t := range ct.conns {
		if t.Before(cutoff) {
			delete(ct.conns, id)
			removed++
		}
	}

	return removed
}
