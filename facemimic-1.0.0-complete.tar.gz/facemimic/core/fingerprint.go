// Package core provides Chrome/Facebook exact fingerprinting capabilities.
// This module ensures the TLS ClientHello and HTTP/2 behavior match Chrome exactly.
package core

import (
	"crypto/rand"
	"encoding/binary"
	"math/big"
	"time"
)

// ChromeFingerprint represents Chrome's exact TLS fingerprint parameters.
// These values are extracted from actual Chrome browser network captures.
type ChromeFingerprint struct {
	// TLS Version
	Version uint16

	// Cipher Suites in exact Chrome order
	CipherSuites []uint16

	// Extensions in exact Chrome order
	Extensions []uint16

	// Supported Versions (TLS 1.3, 1.2)
	SupportedVersions []uint16

	// Signature Algorithms in Chrome order
	SignatureAlgorithms []uint16

	// Curve Groups for key exchange
	CurveGroups []uint16

	// ALPN protocols
	ALPNProtocols []string

	// Point formats
	ECPointFormats []uint8
}

// Chrome120Fingerprint returns the exact fingerprint of Chrome 120.
// This is the most common Chrome version and provides excellent compatibility.
func Chrome120Fingerprint() *ChromeFingerprint {
	return &ChromeFingerprint{
		Version: 0x0303, // TLS 1.2 (advertised, will negotiate TLS 1.3)

		// Cipher suites exactly as Chrome 120 sends them
		CipherSuites: []uint16{
			0x1301, // TLS_AES_128_GCM_SHA256
			0x1302, // TLS_AES_256_GCM_SHA384
			0x1303, // TLS_CHACHA20_POLY1305_SHA256
			0xc02b, // TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256
			0xc02f, // TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256
			0xc02c, // TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384
			0xc030, // TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384
			0xcca9, // TLS_ECDHE_ECDSA_WITH_CHACHA20_POLY1305_SHA256
			0xcca8, // TLS_ECDHE_RSA_WITH_CHACHA20_POLY1305_SHA256
			0xc013, // TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA
			0xc014, // TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA
			0x002f, // TLS_RSA_WITH_AES_128_GCM_SHA256
			0x0035, // TLS_RSA_WITH_AES_256_GCM_SHA384
		},

		// Extensions in exact Chrome order (critical!)
		Extensions: []uint16{
			0x0000, // server_name
			0x0017, // extended_master_secret
			0xff01, // renegotiation_info
			0x002b, // supported_versions
			0x000b, // ec_point_formats
			0x000d, // signature_algorithms
			0x000a, // supported_groups (elliptic_curves)
			0x0010, // application_layer_protocol_negotiation
			0x0005, // status_request (OCSP stapling)
			0x0012, // signed_certificate_timestamp
			0x7550, // compress_certificate
			0x0015, // padding
		},

		// Supported TLS versions
		SupportedVersions: []uint16{
			0x0304, // TLS 1.3
			0x0303, // TLS 1.2
		},

		// Signature algorithms in Chrome order
		SignatureAlgorithms: []uint16{
			0x0403, // ECDSA_SECP256R1_SHA256
			0x0503, // ECDSA_SECP384R1_SHA384
			0x0603, // ECDSA_SECP521R1_SHA512
			0x0804, // RSA_PSS_RSAE_SHA256
			0x0805, // RSA_PSS_RSAE_SHA384
			0x0806, // RSA_PSS_RSAE_SHA512
			0x0401, // RSA_PKCS1_SHA256
			0x0501, // RSA_PKCS1_SHA384
			0x0601, // RSA_PKCS1_SHA512
			0x0203, // ECDSA_SHA1 (legacy)
			0x0201, // RSA_PKCS1_SHA1 (legacy)
		},

		// Supported curve groups
		CurveGroups: []uint16{
			0x001d, // X25519
			0x0017, // secp256r1
			0x0018, // secp384r1
			0x0019, // secp521r1
		},

		// ALPN protocols
		ALPNProtocols: []string{"h2", "http/1.1"},

		// EC point formats
		ECPointFormats: []uint8{0x00}, // uncompressed
	}
}

// FacebookProfile represents Facebook-specific traffic patterns.
type FacebookProfile struct {
	// Target domains
	Domains []string

	// HTTP/2 Settings
	H2Settings H2SettingsProfile

	// Headers pattern
	Headers HeadersProfile

	// Traffic patterns
	Traffic TrafficPattern
}

// H2SettingsProfile contains HTTP/2 settings that match Facebook's expectations.
type H2SettingsProfile struct {
	HeaderTableSize      uint32
	EnablePush           uint32
	MaxConcurrentStreams uint32
	InitialWindowSize    uint32
	MaxFrameSize         uint32
	MaxHeaderListSize    uint32
	UnknownSettings      []uint32 // GREASE settings
}

// HeadersProfile contains HTTP header patterns.
type HeadersProfile struct {
	UserAgent      string
	Accept         string
	AcceptLanguage string
	AcceptEncoding string
	Priority       string // HTTP/2 priority header
}

// TrafficPattern describes realistic traffic timing.
type TrafficPattern struct {
	// Inter-packet delays
	MinInterPacketDelay time.Duration
	MaxInterPacketDelay time.Duration

	// PING frame intervals
	MinPingInterval time.Duration
	MaxPingInterval time.Duration

	// Connection behavior
	InitialWindowSize    uint32
	MaxConcurrentStreams uint32
}

// DefaultFacebookProfile returns the default Facebook traffic profile.
func DefaultFacebookProfile() *FacebookProfile {
	return &FacebookProfile{
		Domains: []string{
			"www.facebook.com",
			"facebook.com",
			"m.facebook.com",
			"fbcdn.net",
			"fbstatic-a.akamaihd.net",
		},

		H2Settings: H2SettingsProfile{
			HeaderTableSize:      65536,
			EnablePush:           0,
			MaxConcurrentStreams: 1000,
			InitialWindowSize:    6291456, // 6MB - Chrome default
			MaxFrameSize:         16384,
			MaxHeaderListSize:    262144,
			UnknownSettings:      generateGREASESettings(),
		},

		Headers: HeadersProfile{
			UserAgent:      "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
			Accept:         "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8",
			AcceptLanguage: "en-US,en;q=0.9",
			AcceptEncoding: "gzip, deflate, br",
			Priority:       "u=0, i",
		},

		Traffic: TrafficPattern{
			MinInterPacketDelay:    5 * time.Millisecond,
			MaxInterPacketDelay:    50 * time.Millisecond,
			MinPingInterval:        15 * time.Second,
			MaxPingInterval:        45 * time.Second,
			InitialWindowSize:      6291456,
			MaxConcurrentStreams:   1000,
		},
	}
}

// generateGREASESettings generates random GREASE settings values.
func generateGREASESettings() []uint32 {
	greaseValues := make([]uint32, 2)
	for i := range greaseValues {
		greaseValues[i] = generateGREASEValue()
	}
	return greaseValues
}

// generateGREASEValue generates a single GREASE value.
// GREASE values follow the pattern: 0x0A0A, 0x1A1A, 0x2A2A, etc.
func generateGREASEValue() uint32 {
	n, _ := rand.Int(rand.Reader, big.NewInt(16))
	return uint32(0x0A0A + n.Int64()*0x1000)
}

// GREASEExtension generates a GREASE extension with proper length.
func GREASEExtension() []byte {
	// GREASE extension: 2 bytes type + 2 bytes length + random data
	extType := generateGREASEValue()
	length := 0

	// Randomly add padding
	if n, err := rand.Int(rand.Reader, big.NewInt(2)); err == nil && n.Int64() > 0 {
		length = int(n.Int64() * 4)
	}

	ext := make([]byte, 4+length)
	binary.BigEndian.PutUint16(ext[0:2], uint16(extType))
	binary.BigEndian.PutUint16(ext[2:4], uint16(length))
	if length > 0 {
		rand.Read(ext[4:])
	}

	return ext
}

// ChromeHTTP2Settings returns HTTP/2 settings exactly as Chrome sends them.
func ChromeHTTP2Settings() map[uint16]uint32 {
	return map[uint16]uint32{
		0x1: 65536,   // HEADER_TABLE_SIZE
		0x3: 1000,    // MAX_CONCURRENT_STREAMS
		0x4: 6291456, // INITIAL_WINDOW_SIZE (6MB)
		0x5: 16384,   // MAX_FRAME_SIZE
		0x6: 262144,  // MAX_HEADER_LIST_SIZE
	}
}

// ChromePriorityFrame returns a priority frame that Chrome would send.
func ChromePriorityFrame(streamID uint32) []byte {
	// Priority frame: 9 byte header + 5 byte payload
	frame := make([]byte, 14)

	// Frame header
	frame[0] = 0 // Length (5 bytes payload)
	frame[1] = 0
	frame[2] = 5
	frame[3] = 0x02 // Type: PRIORITY
	frame[4] = 0x20 // Flags: end headers

	// Stream ID
	binary.BigEndian.PutUint32(frame[5:9], streamID)

	// Priority payload: exclusive=0, stream dependency=0 or 3, weight=16-255
	exclusive := byte(0)
	streamDep := uint32(0)
	weight := byte(41) // Chrome typical value

	binary.BigEndian.PutUint32(frame[9:13], (exclusive<<31)|streamDep)
	frame[13] = weight

	return frame
}

// GenerateChromeWindowUpdate generates a WINDOW_UPDATE frame matching Chrome's behavior.
func GenerateChromeWindowUpdate(streamID uint32, increment uint32) []byte {
	frame := make([]byte, 13)

	// Frame header
	frame[0] = 0
	frame[1] = 0
	frame[2] = 4 // 4 bytes payload
	frame[3] = 0x08 // WINDOW_UPDATE type
	frame[4] = 0 // No flags

	// Stream ID
	binary.BigEndian.PutUint32(frame[5:9], streamID)

	// Window increment (R bit = 0)
	binary.BigEndian.PutUint32(frame[9:13], increment&0x7FFFFFFF)

	return frame
}

// GenerateChromePing generates a PING frame with random opaque data.
func GenerateChromePing() []byte {
	frame := make([]byte, 17)

	// Frame header
	frame[0] = 0
	frame[1] = 0
	frame[2] = 8 // 8 bytes payload
	frame[3] = 0x06 // PING type
	frame[4] = 0 // No flags (not ACK)
	binary.BigEndian.PutUint32(frame[5:9], 0) // Stream 0

	// Random opaque data
	rand.Read(frame[9:17])

	return frame
}

// GenerateChromePingAck generates a PING ACK frame.
func GenerateChromePingAck(opaqueData []byte) []byte {
	frame := make([]byte, 17)

	// Frame header
	frame[0] = 0
	frame[1] = 0
	frame[2] = 8
	frame[3] = 0x06 // PING type
	frame[4] = 0x01 // ACK flag
	binary.BigEndian.PutUint32(frame[5:9], 0)

	// Copy opaque data
	copy(frame[9:17], opaqueData[:8])

	return frame
}

// GetFacebookServerHeader returns headers that Facebook servers typically send.
func GetFacebookServerHeader() map[string]string {
	return map[string]string{
		"server":                  "proxygen-bolt",
		"content-type":            "text/html; charset=utf-8",
		"x-frame-options":         "DENY",
		"x-content-type-options":  "nosniff",
		"strict-transport-security": "max-age=15552000; preload",
		"vary":                    "Accept-Encoding",
	}
}

// CalculatePadding calculates realistic padding for HTTP/2 frames.
// Chrome typically adds padding to normalize frame sizes.
func CalculatePadding(payloadLen int, mtu int) int {
	// Chrome's padding strategy:
	// 1. Small payloads get random padding
	// 2. Medium payloads try to reach common sizes
	// 3. Large payloads get minimal padding

	if payloadLen < 256 {
		// Small payload: add random padding
		n, _ := rand.Int(rand.Reader, big.NewInt(256))
		return int(n.Int64())
	}

	if payloadLen < mtu-9 {
		// Try to fill to MTU
		remaining := mtu - 9 - payloadLen
		if remaining > 255 {
			remaining = 255
		}
		n, _ := rand.Int(rand.Reader, big.NewInt(int64(remaining)))
		return int(n.Int64())
	}

	// Large payload: minimal or no padding
	n, _ := rand.Int(rand.Reader, big.NewInt(16))
	return int(n.Int64())
}

// GenerateRealisticDelay generates a realistic network delay.
func GenerateRealisticDelay(minMs, maxMs int) time.Duration {
	if minMs >= maxMs {
		return time.Duration(minMs) * time.Millisecond
	}
	n, _ := rand.Int(rand.Reader, big.NewInt(int64(maxMs-minMs)))
	return time.Duration(minMs+int(n.Int64())) * time.Millisecond
}

// CalculateJitter calculates random jitter for timing obfuscation.
func CalculateJitter(baseDelay time.Duration, jitterPercent float64) time.Duration {
	if jitterPercent <= 0 {
		return baseDelay
	}
	jitterRange := float64(baseDelay) * jitterPercent
	n, _ := rand.Int(rand.Reader, big.NewInt(int64(jitterRange*2)))
	jitter := time.Duration(n.Int64()) - time.Duration(jitterRange)
	return baseDelay + jitter
}

// StreamPriority represents HTTP/2 stream priority settings.
type StreamPriority struct {
	Exclusive     bool
	StreamDep     uint32
	Weight        uint8
}

// DefaultStreamPriority returns Chrome's default stream priority.
func DefaultStreamPriority() StreamPriority {
	return StreamPriority{
		Exclusive: false,
		StreamDep: 0,
		Weight:    16,
	}
}

// EncodePriority encodes priority into a 5-byte payload.
func EncodePriority(p StreamPriority) []byte {
	buf := make([]byte, 5)
	var dep uint32
	if p.Exclusive {
		dep = 0x80000000
	}
	dep |= p.StreamDep & 0x7FFFFFFF
	binary.BigEndian.PutUint32(buf[0:4], dep)
	buf[4] = p.Weight
	return buf
}
