#!/bin/bash
#
# FaceMimic One-Line VPS Installer
# This script installs and configures FaceMimic automatically
#
# Usage: curl -fsSL https://your-domain.com/install.sh | bash
# Or: wget -qO- https://your-domain.com/install.sh | bash
#

set -e

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m'

# Banner
show_banner() {
    clear
    echo -e "${CYAN}"
    echo "╔═══════════════════════════════════════════════════════════════╗"
    echo "║                                                               ║"
    echo "║     ███████╗ █████╗ ██╗     ██╗      ██████╗ ██╗ ██████╗     ║"
    echo "║     ██╔════╝██╔══██╗██║     ██║     ██╔════╝ ██║██╔════╝     ║"
    echo "║     █████╗  ███████║██║     ██║     ██║  ███╗██║██║          ║"
    echo "║     ██╔══╝  ██╔══██║██║     ██║     ██║   ██║██║██║          ║"
    echo "║     ██║     ██║  ██║███████╗███████╗╚██████╔╝██║╚██████╗     ║"
    echo "║     ╚═╝     ╚═╝  ╚═╝╚══════╝╚══════╝ ╚═════╝ ╚═╝ ╚═════╝     ║"
    echo "║                                                               ║"
    echo "║           Censorship-Resistant Tunneling Protocol            ║"
    echo "║                    One-Click Installer                        ║"
    echo "║                                                               ║"
    echo "╚═══════════════════════════════════════════════════════════════╝"
    echo -e "${NC}"
}

# Logging
log_info() { echo -e "${GREEN}[✓]${NC} $1"; }
log_warn() { echo -e "${YELLOW}[!]${NC} $1"; }
log_error() { echo -e "${RED}[✗]${NC} $1"; }
log_step() { echo -e "${BLUE}[→]${NC} $1"; }

# Check root
check_root() {
    if [ "$EUID" -ne 0 ]; then
        log_error "Please run as root: sudo bash install.sh"
        exit 1
    fi
}

# Detect OS
detect_os() {
    if [ -f /etc/os-release ]; then
        . /etc/os-release
        OS=$ID
        VER=$VERSION_ID
    elif [ -f /etc/redhat-release ]; then
        OS="centos"
    else
        OS="unknown"
    fi
    log_info "Detected OS: $OS $VER"
}

# Install dependencies
install_dependencies() {
    log_step "Installing dependencies..."
    
    case $OS in
        ubuntu|debian)
            apt-get update -qq
            apt-get install -y -qq curl wget unzip tar openssl certbot chrony > /dev/null
            ;;
        centos|rhel|fedora)
            yum install -y -q curl wget unzip tar openssl certbot chrony > /dev/null
            ;;
        *)
            log_error "Unsupported OS: $OS"
            exit 1
            ;;
    esac
    
    log_info "Dependencies installed"
}

# Install Go
install_go() {
    if command -v go &> /dev/null; then
        GO_VERSION=$(go version | awk '{print $3}')
        log_info "Go already installed: $GO_VERSION"
        return
    fi
    
    log_step "Installing Go 1.22..."
    
    GO_VERSION="1.22.5"
    ARCH=$(uname -m)
    
    case $ARCH in
        x86_64) GO_ARCH="amd64" ;;
        aarch64) GO_ARCH="arm64" ;;
        *) log_error "Unsupported architecture: $ARCH"; exit 1 ;;
    esac
    
    wget -q "https://go.dev/dl/go${GO_VERSION}.linux-${GO_ARCH}.tar.gz"
    tar -C /usr/local -xzf "go${GO_VERSION}.linux-${GO_ARCH}.tar.gz"
    rm "go${GO_VERSION}.linux-${GO_ARCH}.tar.gz"
    
    export PATH=$PATH:/usr/local/go/bin
    echo 'export PATH=$PATH:/usr/local/go/bin' >> ~/.bashrc
    echo 'export PATH=$PATH:/usr/local/go/bin' >> /etc/profile
    
    log_info "Go installed: $(/usr/local/go/bin/go version)"
}

# Generate strong password
generate_password() {
    openssl rand -base64 32 | tr -d '/+=' | head -c 32
}

# Get server IP
get_server_ip() {
    curl -s ifconfig.me || curl -s ip.sb || curl -s ipinfo.io/ip
}

# Install FaceMimic
install_facemimic() {
    log_step "Installing FaceMimic..."
    
    INSTALL_DIR="/opt/facemimic"
    mkdir -p $INSTALL_DIR
    cd $INSTALL_DIR
    
    # Download or build
    if [ -f "/tmp/facemimic/build/bin/kworker-d" ]; then
        cp /tmp/facemimic/build/bin/* $INSTALL_DIR/
    else
        # Download pre-built binaries (you should host these)
        log_step "Downloading pre-built binaries..."
        
        ARCH=$(uname -m)
        case $ARCH in
            x86_64) BINARY_ARCH="amd64" ;;
            aarch64) BINARY_ARCH="arm64" ;;
        esac
        
        # For now, we'll build from source
        log_step "Building from source..."
        
        git clone --depth 1 https://github.com/facemimic/core.git /tmp/facemimic 2>/dev/null || true
        cd /tmp/facemimic
        
        /usr/local/go/bin/go mod download
        /usr/local/go/bin/go build -ldflags="-s -w" -o "$INSTALL_DIR/kworker-d" ./server
        /usr/local/go/bin/go build -ldflags="-s -w" -o "$INSTALL_DIR/kworker-u" ./client
        
        cd $INSTALL_DIR
    fi
    
    chmod +x kworker-d kworker-u
    
    log_info "FaceMimic binaries installed"
}

# Configure SSL certificate
configure_ssl() {
    log_step "Configuring SSL certificate..."
    
    DOMAIN=""
    USE_SELF_SIGNED=false
    
    read -p "$(echo -e ${CYAN}Do you have a domain name? (y/n): ${NC})" -n 1 -r
    echo
    
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        read -p "$(echo -e ${CYAN}Enter your domain name: ${NC})" DOMAIN
        
        # Check if domain resolves to this server
        SERVER_IP=$(get_server_ip)
        DOMAIN_IP=$(dig +short $DOMAIN | head -1)
        
        if [ "$SERVER_IP" != "$DOMAIN_IP" ]; then
            log_warn "Domain does not resolve to this server"
            log_warn "Server IP: $SERVER_IP, Domain IP: $DOMAIN_IP"
            read -p "$(echo -e ${CYAN}Continue anyway? (y/n): ${NC})" -n 1 -r
            echo
            if [[ ! $REPLY =~ ^[Yy]$ ]]; then
                USE_SELF_SIGNED=true
            fi
        fi
        
        if [ "$USE_SELF_SIGNED" = false ]; then
            # Get Let's Encrypt certificate
            certbot certonly --standalone -d $DOMAIN --non-interactive --agree-tos --email "admin@$DOMAIN"
            
            CERT_FILE="/etc/letsencrypt/live/$DOMAIN/fullchain.pem"
            KEY_FILE="/etc/letsencrypt/live/$DOMAIN/privkey.pem"
        fi
    else
        USE_SELF_SIGNED=true
    fi
    
    if [ "$USE_SELF_SIGNED" = true ]; then
        log_step "Generating self-signed certificate..."
        mkdir -p $INSTALL_DIR/certs
        openssl req -x509 -newkey rsa:2048 \
            -keyout $INSTALL_DIR/certs/key.pem \
            -out $INSTALL_DIR/certs/cert.pem \
            -days 365 -nodes \
            -subj "/CN=www.facebook.com" 2>/dev/null
        
        CERT_FILE="$INSTALL_DIR/certs/cert.pem"
        KEY_FILE="$INSTALL_DIR/certs/key.pem"
        DOMAIN="www.facebook.com"
    fi
    
    log_info "SSL certificate configured"
}

# Create configuration
create_config() {
    log_step "Creating configuration..."
    
    PASSWORD=$(generate_password)
    SERVER_IP=$(get_server_ip)
    LISTEN_PORT=1080
    
    cat > $INSTALL_DIR/config.json << EOF
{
    "server_ip": "$SERVER_IP",
    "listen_port": $LISTEN_PORT,
    "target_domain": "www.facebook.com",
    "password": "$PASSWORD",
    "cert_file": "$CERT_FILE",
    "key_file": "$KEY_FILE",
    "connection_timeout": "10s",
    "handshake_timeout": "5s",
    "max_connection_duration": "30m",
    "max_throughput_bytes": 524288000,
    "heartbeat_min_interval": "15s",
    "heartbeat_max_interval": "45s",
    "replay_cache_size": 10000,
    "log_level": "info"
}
EOF
    
    chmod 600 $INSTALL_DIR/config.json
    
    log_info "Configuration created"
}

# Create systemd service
create_service() {
    log_step "Creating systemd service..."
    
    cat > /etc/systemd/system/facemimic.service << 'EOF'
[Unit]
Description=FaceMimic Tunnel Server
After=network.target

[Service]
Type=simple
ExecStart=/opt/facemimic/kworker-d /opt/facemimic/config.json
WorkingDirectory=/opt/facemimic
Restart=on-failure
RestartSec=5s
LimitNOFILE=1048576
AmbientCapabilities=CAP_NET_BIND_SERVICE

[Install]
WantedBy=multi-user.target
EOF
    
    systemctl daemon-reload
    systemctl enable facemimic
    
    log_info "Systemd service created"
}

# Configure firewall
configure_firewall() {
    log_step "Configuring firewall..."
    
    if command -v ufw &> /dev/null; then
        ufw --force enable
        ufw default deny incoming
        ufw default allow outgoing
        ufw allow ssh
        ufw allow 80/tcp
        ufw allow 443/tcp
        ufw reload
        log_info "UFW firewall configured"
    elif command -v firewall-cmd &> /dev/null; then
        firewall-cmd --permanent --add-port=80/tcp
        firewall-cmd --permanent --add-port=443/tcp
        firewall-cmd --reload
        log_info "Firewalld configured"
    else
        log_warn "No firewall detected, please configure manually"
    fi
}

# Generate client config
generate_client_config() {
    log_step "Generating client configurations..."
    
    SERVER_IP=$(get_server_ip)
    PASSWORD=$(grep -o '"password": "[^"]*"' $INSTALL_DIR/config.json | cut -d'"' -f4)
    
    # Generate client config file
    cat > $INSTALL_DIR/client-config.json << EOF
{
    "server_ip": "$SERVER_IP",
    "listen_port": 1080,
    "target_domain": "www.facebook.com",
    "password": "$PASSWORD",
    "connection_timeout": "10s",
    "handshake_timeout": "5s",
    "max_connection_duration": "30m",
    "max_throughput_bytes": 524288000,
    "heartbeat_min_interval": "15s",
    "heartbeat_max_interval": "45s",
    "replay_cache_size": 10000,
    "log_level": "info"
}
EOF
    
    # Generate Clash config
    mkdir -p $INSTALL_DIR/client-configs
    cat > $INSTALL_DIR/client-configs/clash.yaml << EOF
port: 7890
socks-port: 7891
allow-lan: true
mode: Rule
log-level: info

proxies:
  - name: "FaceMimic"
    type: socks5
    server: 127.0.0.1
    port: 1080

proxy-groups:
  - name: "Proxy"
    type: select
    proxies:
      - FaceMimic
      - DIRECT

rules:
  - MATCH,Proxy
EOF
    
    # Generate SingBox config
    cat > $INSTALL_DIR/client-configs/singbox.json << EOF
{
    "log": {"level": "info"},
    "inbounds": [
        {
            "type": "tun",
            "tag": "tun-in",
            "inet4_address": "172.19.0.1/30",
            "auto_route": true,
            "strict_route": true
        },
        {
            "type": "socks",
            "tag": "socks-in",
            "listen": "127.0.0.1",
            "listen_port": 10800
        }
    ],
    "outbounds": [
        {
            "type": "socks",
            "tag": "facemimic-out",
            "server": "127.0.0.1",
            "server_port": 1080,
            "version": "5"
        }
    ],
    "route": {
        "rules": [
            {"outbound": "facemimic-out"}
        ]
    }
}
EOF
    
    # Generate connection URL
    CONNECTION_URL="facemimic://${SERVER_IP}:443?password=${PASSWORD}#FaceMimic"
    echo "$CONNECTION_URL" > $INSTALL_DIR/client-configs/connection-url.txt
    
    # Generate QR code for mobile
    if command -v qrencode &> /dev/null; then
        qrencode -o $INSTALL_DIR/client-configs/qr-code.png "$CONNECTION_URL"
    fi
    
    log_info "Client configurations generated"
}

# Print success message
print_success() {
    echo ""
    echo -e "${GREEN}╔═══════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${GREEN}║                    Installation Complete!                     ║${NC}"
    echo -e "${GREEN}╚═══════════════════════════════════════════════════════════════╝${NC}"
    echo ""
    echo -e "${CYAN}Server Information:${NC}"
    echo -e "  Server IP:     ${YELLOW}$(get_server_ip)${NC}"
    echo -e "  Password:      ${YELLOW}$(grep -o '"password": "[^"]*"' $INSTALL_DIR/config.json | cut -d'"' -f4)${NC}"
    echo ""
    echo -e "${CYAN}Service Commands:${NC}"
    echo -e "  Start:         ${YELLOW}systemctl start facemimic${NC}"
    echo -e "  Stop:          ${YELLOW}systemctl stop facemimic${NC}"
    echo -e "  Status:        ${YELLOW}systemctl status facemimic${NC}"
    echo -e "  Logs:          ${YELLOW}journalctl -u facemimic -f${NC}"
    echo ""
    echo -e "${CYAN}Client Config Files:${NC}"
    echo -e "  Location:      ${YELLOW}$INSTALL_DIR/client-configs/${NC}"
    echo -e "  Clash:         ${YELLOW}clash.yaml${NC}"
    echo -e "  SingBox:       ${YELLOW}singbox.json${NC}"
    echo ""
    echo -e "${CYAN}Mobile Setup:${NC}"
    echo -e "  1. Install 'Clash for Android' or 'SingBox' app"
    echo -e "  2. Import the config file from ${YELLOW}$INSTALL_DIR/client-configs/${NC}"
    echo -e "  3. Or scan the QR code in ${YELLOW}$INSTALL_DIR/client-configs/qr-code.png${NC}"
    echo ""
    echo -e "${GREEN}FaceMimic is now running!${NC}"
}

# Main installation
main() {
    show_banner
    
    check_root
    detect_os
    install_dependencies
    install_go
    install_facemimic
    configure_ssl
    create_config
    create_service
    configure_firewall
    generate_client_config
    
    # Start service
    systemctl start facemimic
    
    print_success
}

# Run main
main "$@"
