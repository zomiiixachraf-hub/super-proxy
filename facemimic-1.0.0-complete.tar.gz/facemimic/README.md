# FaceMimic 🛡️

**بروتوكول نفق متطور لمقاومة الرقابة مع تمويه كامل**

[![Go Version](https://img.shields.io/badge/Go-1.22+-00ADD8?style=flat&logo=go)](https://golang.org)
[![License](https://img.shields.io/badge/License-MIT-green.svg)](LICENSE)
[![Platform](https://img.shields.io/badge/Platform-Linux%20%7C%20Windows%20%7C%20macOS-blue)](https://github.com/facemimic/core)

---

## 🚀 التثبيت السريع

### الخادم (VPS) - بنقرة واحدة

```bash
curl -fsSL https://your-server.com/install-vps.sh | sudo bash
```

### عرض معلومات الاتصال

```bash
facemimic-info
```

---

## 📱 إعداد الهاتف

### الطريقة الأولى: تطبيق FaceMimic (الأسهل)

1. حمل الـ APK من لوحة التحكم
2. أدخل بيانات الاتصال
3. اتصل! 🎉

### الطريقة الثانية: Clash for Android

```bash
# استيراد التكوين
cat /opt/facemimic/client-configs/clash.yaml
```

### الطريقة الثالثة: SingBox

```bash
# استيراد التكوين  
cat /opt/facemimic/client-configs/singbox.json
```

### الطريقة الرابعة: أي تطبيق SOCKS5

```
Type: SOCKS5
Server: YOUR_SERVER_IP
Port: 443
Password: YOUR_PASSWORD
```

---

## 🖥️ لوحة التحكم

```
http://YOUR_SERVER_IP:8080
```

---

## 🔧 إدارة الخادم

```bash
# عرض الحالة
systemctl status facemimic

# بدء/إيقاف
systemctl start facemimic
systemctl stop facemimic

# عرض السجلات
journalctl -u facemimic -f

# تغيير كلمة المرور
facemimic-manager
```

---

## 📋 المتطلبات

### الخادم
- Ubuntu 20.04+ / Debian 11+ / CentOS 8+
- 1GB RAM
- 10GB Storage
- منفذ 80 و 443 مفتوحين

### العميل
- Android 7.0+
- iOS 12.0+ (قريباً)
- Windows 10+
- macOS 10.15+
- Linux

---

## 🌟 المميزات

| الميزة | الوصف |
|--------|-------|
| 🔒 **TLS 1.3** | تشفير قوي مع بصمة Chrome |
| 🎭 **تمويه HTTP/2** | حركة مرور مطابقة للمواقع الحقيقية |
| 🛡️ **دفاع ضد التحقيقات** | تمرير التحقيقات للهدف الحقيقي |
| 📱 **سهولة الاستخدام** | واجهة بسيطة وتكوين تلقائي |
| 🔄 **تدوير الاتصال** | تجديد تلقائي كل 30 دقيقة |
| 🌐 **لوحة تحكم** | مراقبة وإدارة من المتصفح |

---

## 🏗️ البناء من المصدر

```bash
# استنساخ المشروع
git clone https://github.com/facemimic/core.git
cd core

# بناء
make all

# بناء لجميع المنصات
make release
```

---

## 📁 هيكل المشروع

```
facemimic/
├── server/           # كود الخادم
├── client/           # كود العميل
├── core/            # المكتبة الأساسية
│   ├── fingerprint.go  # بصمة Chrome
│   ├── masquerade.go   # تمويه HTTP/2
│   └── handshake.go    # المصادقة
├── client-configs/  # ملفات تكوين الهاتف
├── install-vps.sh   # سكريبت التثبيت
├── facemimic-manager.sh # أداة الإدارة
└── Makefile         # نظام البناء
```

---

## 🔐 الأمان

### ⚠️ تحذير مهم

```
يجب استضافة الخادم على ASN يخدم حركة Facebook!
مثال: AS32934 (Facebook), AS13335 (Cloudflare)
```

### نصائح الأمان

1. غيّر كلمة المرور كل فترة
2. استخدم شهادة SSL صالحة
3. راقب السجلات بانتظام
4. حدّث البرنامج باستمرار

---

## 📊 الأداء

| المقياس | القيمة |
|---------|--------|
| زمن الاستجابة | < 50ms |
| سرعة النقل | > 100 Mbps |
| استخدام الذاكرة | ~ 50MB |
| استخدام CPU | < 5% |

---

## 🆘 استكشاف الأخطاء

### لا يمكن الاتصال

```bash
# تحقق من حالة الخدمة
systemctl status facemimic

# تحقق من المنافذ
ufw status

# راجع السجلات
journalctl -u facemimic -n 50
```

### بطء الاتصال

1. اختر خادم قريب من موقعك
2. تأكد من سرعة الخادم
3. جرب وقت آخر

---

## 📞 الدعم

- 📖 [التوثيق](https://docs.facemimic.io)
- 💬 [Telegram](https://t.me/facemimic)
- 🐛 [المشاكل](https://github.com/facemimic/core/issues)

---

## 📜 الرخصة

MIT License - راجع ملف [LICENSE](LICENSE)

---

## 🙏 الشكر

- [uTLS](https://github.com/refraction-networking/utls) - بصمة TLS
- [smux](https://github.com/xtaci/smux) - تعدد الإرسال
- [logrus](https://github.com/sirupsen/logrus) - التسجيل

---

<p align="center">
  صُنع بـ ❤️ للحرية الرقمية
</p>
