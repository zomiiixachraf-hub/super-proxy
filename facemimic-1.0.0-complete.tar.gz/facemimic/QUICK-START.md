# FaceMimic - دليل التثبيت السريع

## 🚀 تثبيت الخادم (VPS) بنقرة واحدة

```bash
curl -fsSL https://your-server.com/install-vps.sh | sudo bash
```

أو:

```bash
wget -qO- https://your-server.com/install-vps.sh | sudo bash
```

## 📱 إعداد الهاتف

### الطريقة الأولى: تطبيق FaceMimic (الأسهل)

1. **تحميل التطبيق**
   - أندرويد: حمل APK من لوحة التحكم
   - آيفون: قريباً

2. **إدخال بيانات الاتصال**
   - Server IP: `IP_الخادم`
   - Password: `كلمة_المرور`
   - Port: `443`

3. **اتصل!** 🎉

---

### الطريقة الثانية: Clash for Android

1. **تحميل التطبيق**
   - من Google Play: "Clash for Android"
   - أو من GitHub: Alvin9999/clash-for-android

2. **استيراد التكوين**
   ```bash
   # على الخادم، اعرض التكوين:
   cat /opt/facemimic/client-configs/clash.yaml
   ```

3. **أو امسح الكود QR**
   - افتح لوحة التحكم: `http://IP_الخادم:8080`
   - امسح الكود بتطبيق Clash

---

### الطريقة الثالثة: SingBox

1. **تحميل التطبيق**
   - من Google Play: "SingBox"
   - أو من GitHub: SagerNet/sing-box

2. **استيراد التكوين**
   ```bash
   # على الخادم
   cat /opt/facemimic/client-configs/singbox.json
   ```

---

### الطريقة الرابعة: أي تطبيق SOCKS5

استخدم أي تطبيق يدعم SOCKS5:
- **Drony**
- **Postern**
- **Every Proxy**

الإعدادات:
```
Type: SOCKS5
Server: IP_الخادم
Port: 443
Password: كلمة_المرور
```

---

## 🔧 إدارة الخادم

### عرض معلومات الاتصال
```bash
facemimic-info
# أو
cat /opt/facemimic/client-configs/connection-url.txt
```

### بدء/إيقاف الخدمة
```bash
systemctl start facemimic    # بدء
systemctl stop facemimic     # إيقاف
systemctl restart facemimic  # إعادة تشغيل
systemctl status facemimic   # حالة
```

### عرض السجلات
```bash
journalctl -u facemimic -f
```

### تغيير كلمة المرور
```bash
# توليد كلمة جديدة
NEW_PASS=$(openssl rand -base64 32)
sed -i "s/\"password\": \"[^\"]*\"/\"password\": \"$NEW_PASS\"/" /opt/facemimic/config.json

# إعادة التشغيل
systemctl restart facemimic

# عرض كلمة المرور الجديدة
echo "New Password: $NEW_PASS"
```

---

## 🌐 لوحة التحكم

افتح في المتصفح:
```
http://IP_الخادم:8080
```

من لوحة التحكم يمكنك:
- ✅ عرض حالة الاتصال
- ✅ عرض إحصائيات المرور
- ✅ تحميل ملفات التكوين
- ✅ مسح كود QR

---

## 📲 رابط الاتصال السريع

```
facemimic://IP_الخادم:443?password=كلمة_المرور
```

انسخ هذا الرابط وشاركه مع أجهزتك الأخرى!

---

## 🆘 استكشاف الأخطاء

### لا يمكن الاتصال

1. **تأكد من تشغيل الخدمة**
   ```bash
   systemctl status facemimic
   ```

2. **تأكد من فتح المنافذ**
   ```bash
   ufw status
   # يجب أن تكون 80 و 443 مفتوحة
   ```

3. **تحقق من السجلات**
   ```bash
   journalctl -u facemimic -n 50
   ```

### بطء الاتصال

1. **تأكد من موقع الخادم** (اختر قريب منك)
2. **جرب خادم آخر**
3. **تأكد من سرعة الخادم**

### مشاكل SSL

```bash
# تجديد الشهادة
certbot renew

# أو إنشاء شهادة جديدة
certbot certonly --standalone -d your-domain.com
```

---

## 💡 نصائح مهمة

1. **استخدم خادم في دولة قريبة** لسرعة أفضل
2. **غيّر كلمة المرور** كل فترة
3. **راقب المرور** من لوحة التحكم
4. **احتفظ بنسخة احتياطية** من ملف التكوين

---

## 📞 الدعم

- GitHub: https://github.com/facemimic/core
- Telegram: @facemimic_support
- Email: support@facemimic.io
