// Package main implements the FaceMimic client component with exact Chrome fingerprinting.
// The client provides a SOCKS5 proxy interface that tunnels traffic through the FaceMimic
// server with TLS fingerprint spoofing matching Chrome 120 exactly.
package main

import (
	"bufio"
	"context"
	"crypto/tls"
	"encoding/binary"
	"errors"
	"fmt"
	"io"
	"net"
	"os"
	"os/signal"
	"runtime"
	"sync"
	"sync/atomic"
	"syscall"
	"time"

	"github.com/facemimic/core/config"
	"github.com/facemimic/core/core"
	utls "github.com/refraction-networking/utls"
	"github.com/sirupsen/logrus"
	"github.com/xtaci/smux"
)

// Client state constants
const (
	StateDisconnected = iota
	StateConnecting
	StateConnected
)

// Client holds the state for the FaceMimic client.
type Client struct {
	config *config.Config
	auth   *core.Authenticator

	// Connection management
	conn       net.Conn
	tlsConn    *utls.UConn
	h2Conn     *core.H2Conn
	muxSession *smux.Session
	state      int32
	connMu     sync.RWMutex

	// Lifecycle tracking
	connTime  time.Time
	bytesSent uint64
	bytesRecv uint64

	// Facebook profile
	profile *core.FacebookProfile

	// Shutdown
	shutdownCtx    context.Context
	shutdownCancel context.CancelFunc

	// SOCKS5 listener
	listener net.Listener
}

// NewClient creates a new FaceMimic client instance.
func NewClient(cfg *config.Config) *Client {
	auth := core.NewAuthenticator(cfg.Password, cfg.ReplayCacheSize)
	ctx, cancel := context.WithCancel(context.Background())

	return &Client{
		config:        cfg,
		auth:          auth,
		state:         StateDisconnected,
		shutdownCtx:   ctx,
		shutdownCancel: cancel,
		profile:       core.DefaultFacebookProfile(),
	}
}

// getState returns the current connection state.
func (c *Client) getState() int32 {
	return atomic.LoadInt32(&c.state)
}

// setState updates the connection state.
func (c *Client) setState(state int32) {
	atomic.StoreInt32(&c.state, state)
}

// Connect establishes a tunnel connection to the server with Chrome fingerprint.
func (c *Client) Connect() error {
	if c.getState() == StateConnected {
		return nil
	}

	c.setState(StateConnecting)

	// Dial TCP connection with realistic timing
	dialer := &net.Dialer{
		Timeout:   c.config.ConnectionTimeout,
		KeepAlive: 30 * time.Second,
	}

	// Add random delay to mimic human behavior (Chrome doesn't connect instantly)
	initialDelay := core.GenerateRealisticDelay(50, 200)
	time.Sleep(initialDelay)

	conn, err := dialer.DialContext(c.shutdownCtx, "tcp",
		fmt.Sprintf("%s:443", c.config.ServerIP))
	if err != nil {
		c.setState(StateDisconnected)
		return fmt.Errorf("failed to connect to server: %w", err)
	}

	// Enable TCP optimizations (Chrome behavior)
	if tcpConn, ok := conn.(*net.TCPConn); ok {
		tcpConn.SetNoDelay(true)
		tcpConn.SetKeepAlive(true)
		tcpConn.SetKeepAlivePeriod(30 * time.Second)
		tcpConn.SetReadBuffer(4194304) // 4MB
		tcpConn.SetWriteBuffer(4194304)
	}

	// Generate SessionID for steganographic authentication
	sessionID := c.auth.GenerateSessionID()

	// Create uTLS connection with EXACT Chrome 120 fingerprint
	// This is critical for DPI evasion
	tlsConfig := &utls.Config{
		ServerName:         c.config.TargetDomain,
		InsecureSkipVerify: true, // We use HMAC authentication
		SessionID:          sessionID,
		NextProtos:         []string{"h2", "http/1.1"},
		MinVersion:         tls.VersionTLS12,
		MaxVersion:         tls.VersionTLS13,
	}

	// Use HelloChrome_120 to match Chrome 120 exactly
	// This includes exact extension ordering, GREASE, and cipher suites
	uconn := utls.UClient(conn, tlsConfig, utls.HelloChrome_120)

	// Perform TLS handshake
	if err := uconn.Handshake(); err != nil {
		conn.Close()
		c.setState(StateDisconnected)
		return fmt.Errorf("TLS handshake failed: %w", err)
	}

	// Verify ALPN negotiation (Chrome always prefers h2)
	state := uconn.ConnectionState()
	if state.NegotiatedProtocol != "h2" {
		logrus.WithField("protocol", state.NegotiatedProtocol).Warn("Server did not negotiate h2, but continuing")
	}

	// Log TLS version for debugging
	logrus.WithFields(logrus.Fields{
		"version":           tlsVersionString(state.Version),
		"cipher":            cipherSuiteString(state.CipherSuite),
		"negotiated_protocol": state.NegotiatedProtocol,
		"peer_certificates": len(state.PeerCertificates),
	}).Debug("TLS connection established")

	// Create HTTP/2 masquerade layer with Chrome-exact settings
	h2Config := core.DefaultH2Config()
	h2Config.Profile = c.profile
	h2Conn := core.NewH2Conn(uconn, h2Config)

	// Start heartbeat with Chrome-like timing
	h2Conn.StartHeartbeat(c.shutdownCtx,
		c.config.HeartbeatMinInterval,
		c.config.HeartbeatMaxInterval)

	// Send initial HTTP/2 settings (Chrome exact)
	if err := core.WriteChromeSettings(h2Conn); err != nil {
		uconn.Close()
		conn.Close()
		c.setState(StateDisconnected)
		return fmt.Errorf("failed to send initial settings: %w", err)
	}

	// Wait for server settings ACK (Chrome behavior)
	time.Sleep(10 * time.Millisecond)

	// Create smux client for multiplexing
	muxConfig := smux.DefaultConfig()
	muxConfig.MaxReceiveBuffer = 4194304 // 4MB
	muxConfig.MaxStreamBuffer = 2097152  // 2MB
	muxConfig.KeepAliveInterval = 30 * time.Second
	muxConfig.KeepAliveTimeout = 90 * time.Second

	muxSession, err := smux.Client(h2Conn, muxConfig)
	if err != nil {
		uconn.Close()
		conn.Close()
		c.setState(StateDisconnected)
		return fmt.Errorf("failed to create mux session: %w", err)
	}

	// Store connection state
	c.connMu.Lock()
	c.conn = conn
	c.tlsConn = uconn
	c.h2Conn = h2Conn
	c.muxSession = muxSession
	c.connTime = time.Now()
	c.bytesSent = 0
	c.bytesRecv = 0
	c.connMu.Unlock()

	c.setState(StateConnected)

	logrus.WithFields(logrus.Fields{
		"server":       c.config.ServerIP,
		"target_sni":   c.config.TargetDomain,
		"alpn":         state.NegotiatedProtocol,
		"tls_version":  tlsVersionString(state.Version),
		"fingerprint":  "Chrome_120",
	}).Info("Connected to server with Chrome fingerprint")

	return nil
}

// tlsVersionString converts TLS version to human-readable string.
func tlsVersionString(v uint16) string {
	switch v {
	case tls.VersionTLS10:
		return "TLS 1.0"
	case tls.VersionTLS11:
		return "TLS 1.1"
	case tls.VersionTLS12:
		return "TLS 1.2"
	case tls.VersionTLS13:
		return "TLS 1.3"
	default:
		return fmt.Sprintf("Unknown(0x%04x)", v)
	}
}

// cipherSuiteString converts cipher suite to human-readable string.
func cipherSuiteString(v uint16) string {
	switch v {
	case tls.TLS_AES_128_GCM_SHA256:
		return "TLS_AES_128_GCM_SHA256"
	case tls.TLS_AES_256_GCM_SHA384:
		return "TLS_AES_256_GCM_SHA384"
	case tls.TLS_CHACHA20_POLY1305_SHA256:
		return "TLS_CHACHA20_POLY1305_SHA256"
	case tls.TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256:
		return "TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256"
	case tls.TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384:
		return "TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384"
	default:
		return fmt.Sprintf("Unknown(0x%04x)", v)
	}
}

// Disconnect closes the tunnel connection.
func (c *Client) Disconnect() {
	c.connMu.Lock()
	defer c.connMu.Unlock()

	if c.muxSession != nil {
		c.muxSession.Close()
		c.muxSession = nil
	}
	if c.h2Conn != nil {
		c.h2Conn.Close()
		c.h2Conn = nil
	}
	if c.tlsConn != nil {
		c.tlsConn.Close()
		c.tlsConn = nil
	}
	if c.conn != nil {
		c.conn.Close()
		c.conn = nil
	}

	c.setState(StateDisconnected)
}

// OpenStream opens a new multiplexed stream to the server.
func (c *Client) OpenStream(destIP net.IP, destPort int) (*smux.Stream, error) {
	c.connMu.RLock()
	muxSession := c.muxSession
	c.connMu.RUnlock()

	if muxSession == nil {
		return nil, errors.New("not connected")
	}

	// Open a new stream
	stream, err := muxSession.OpenStream()
	if err != nil {
		return nil, fmt.Errorf("failed to open stream: %w", err)
	}

	// Send destination address (6 bytes: 4 IP + 2 port)
	addrBuf := make([]byte, 6)
	copy(addrBuf[:4], destIP.To4())
	binary.BigEndian.PutUint16(addrBuf[4:6], uint16(destPort))

	if _, err := stream.Write(addrBuf); err != nil {
		stream.Close()
		return nil, fmt.Errorf("failed to send destination address: %w", err)
	}

	return stream, nil
}

// ShouldRotate checks if the connection should be rotated.
func (c *Client) ShouldRotate() bool {
	c.connMu.RLock()
	defer c.connMu.RUnlock()

	if c.connTime.IsZero() {
		return false
	}

	// Check duration (mimic user refreshing page)
	duration := time.Since(c.connTime)
	if duration > c.config.MaxConnectionDuration {
		logrus.WithField("duration", duration).Debug("Connection rotation: duration exceeded")
		return true
	}

	// Check throughput (avoid long-term traffic analysis)
	totalBytes := c.bytesSent + c.bytesRecv
	if totalBytes > uint64(c.config.MaxThroughputBytes) {
		logrus.WithField("bytes", totalBytes).Debug("Connection rotation: throughput exceeded")
		return true
	}

	return false
}

// RotateConnection closes the current connection and establishes a new one.
func (c *Client) RotateConnection() error {
	logrus.Info("Rotating connection (mimicking page refresh)...")

	c.Disconnect()

	// Add realistic delay to mimic user behavior (reading page before refresh)
	delay := core.GenerateRealisticDelay(100, 900)
	time.Sleep(delay * time.Millisecond)

	return c.Connect()
}

// EnsureConnected ensures there is an active connection to the server.
func (c *Client) EnsureConnected() error {
	if c.getState() == StateConnected {
		if c.ShouldRotate() {
			return c.RotateConnection()
		}
		return nil
	}

	return c.Connect()
}

// Run starts the SOCKS5 proxy server.
func (c *Client) Run() error {
	listener, err := net.Listen("tcp", fmt.Sprintf("127.0.0.1:%d", c.config.ListenPort))
	if err != nil {
		return fmt.Errorf("failed to listen on %d: %w", c.config.ListenPort, err)
	}
	c.listener = listener

	logrus.WithField("addr", listener.Addr()).Info("SOCKS5 proxy started")

	// Initial connection
	if err := c.Connect(); err != nil {
		return fmt.Errorf("failed to establish initial connection: %w", err)
	}

	// Start connection monitor
	go c.connectionMonitor()

	// Accept connections
	for {
		select {
		case <-c.shutdownCtx.Done():
			return nil
		default:
			conn, err := listener.Accept()
			if err != nil {
				if c.shutdownCtx.Err() != nil {
					return nil
				}
				logrus.WithError(err).Error("Failed to accept SOCKS5 connection")
				continue
			}

			go c.handleSOCKS5(conn)
		}
	}
}

// connectionMonitor periodically checks connection health.
func (c *Client) connectionMonitor() {
	ticker := time.NewTicker(30 * time.Second)
	defer ticker.Stop()

	for {
		select {
		case <-c.shutdownCtx.Done():
			return
		case <-ticker.C:
			if c.getState() == StateConnected {
				if c.ShouldRotate() {
					if err := c.RotateConnection(); err != nil {
						logrus.WithError(err).Error("Failed to rotate connection")
					}
				}

				// Log statistics
				c.connMu.RLock()
				duration := time.Since(c.connTime)
				sent := c.bytesSent
				recv := c.bytesRecv
				c.connMu.RUnlock()

				logrus.WithFields(logrus.Fields{
					"duration":   duration.Round(time.Second),
					"bytes_sent": sent,
					"bytes_recv": recv,
				}).Debug("Connection statistics")
			}
		}
	}
}

// handleSOCKS5 handles a SOCKS5 client connection.
func (c *Client) handleSOCKS5(conn net.Conn) {
	defer conn.Close()

	if err := c.EnsureConnected(); err != nil {
		logrus.WithError(err).Error("Failed to ensure connection")
		return
	}

	conn.SetDeadline(time.Now().Add(30 * time.Second))
	reader := bufio.NewReader(conn)

	// SOCKS5 greeting
	header, err := reader.Peek(2)
	if err != nil {
		return
	}

	if header[0] != 0x05 {
		logrus.WithField("version", header[0]).Debug("Invalid SOCKS version")
		return
	}

	nmethods := int(header[1])
	greeting := make([]byte, 2+nmethods)
	if _, err := io.ReadFull(reader, greeting); err != nil {
		return
	}

	// No authentication required
	conn.Write([]byte{0x05, 0x00})

	// SOCKS5 request
	request := make([]byte, 4)
	if _, err := io.ReadFull(reader, request); err != nil {
		return
	}

	if request[0] != 0x05 {
		return
	}

	if request[1] != 0x01 {
		conn.Write([]byte{0x05, 0x07, 0x00, 0x01, 0, 0, 0, 0, 0, 0})
		return
	}

	atyp := request[3]
	var destIP net.IP
	var destPort int

	switch atyp {
	case 0x01: // IPv4
		ipv4 := make([]byte, 4)
		if _, err := io.ReadFull(reader, ipv4); err != nil {
			return
		}
		destIP = net.IP(ipv4)

	case 0x03: // Domain name
		domainLen := make([]byte, 1)
		if _, err := io.ReadFull(reader, domainLen); err != nil {
			return
		}
		domain := make([]byte, domainLen[0])
		if _, err := io.ReadFull(reader, domain); err != nil {
			return
		}

		ips, err := net.LookupIP(string(domain))
		if err != nil {
			conn.Write([]byte{0x05, 0x04, 0x00, 0x01, 0, 0, 0, 0, 0, 0})
			return
		}
		for _, ip := range ips {
			if ip.To4() != nil {
				destIP = ip.To4()
				break
			}
		}
		if destIP == nil {
			destIP = ips[0]
		}

	case 0x04: // IPv6
		ipv6 := make([]byte, 16)
		if _, err := io.ReadFull(reader, ipv6); err != nil {
			return
		}
		destIP = net.IP(ipv6)

	default:
		conn.Write([]byte{0x05, 0x08, 0x00, 0x01, 0, 0, 0, 0, 0, 0})
		return
	}

	port := make([]byte, 2)
	if _, err := io.ReadFull(reader, port); err != nil {
		return
	}
	destPort = int(port[0])<<8 | int(port[1])

	logrus.WithFields(logrus.Fields{
		"dest_ip":   destIP.String(),
		"dest_port": destPort,
	}).Debug("SOCKS5 CONNECT request")

	if err := c.EnsureConnected(); err != nil {
		conn.Write([]byte{0x05, 0x03, 0x00, 0x01, 0, 0, 0, 0, 0, 0})
		return
	}

	stream, err := c.OpenStream(destIP, destPort)
	if err != nil {
		logrus.WithError(err).Error("Failed to open stream")
		conn.Write([]byte{0x05, 0x05, 0x00, 0x01, 0, 0, 0, 0, 0, 0})
		return
	}
	defer stream.Close()

	// Success response
	localAddr := conn.LocalAddr().(*net.TCPAddr)
	response := make([]byte, 10)
	response[0] = 0x05
	response[1] = 0x00
	response[2] = 0x00
	response[3] = 0x01
	copy(response[4:8], localAddr.IP.To4())
	binary.BigEndian.PutUint16(response[8:10], uint16(localAddr.Port))
	conn.Write(response)

	conn.SetDeadline(time.Time{})

	var transferred uint64
	done := make(chan struct{}, 2)

	go func() {
		defer func() { done <- struct{}{} }()
		n, _ := io.Copy(stream, conn)
		c.connMu.Lock()
		c.bytesSent += uint64(n)
		c.connMu.Unlock()
		atomic.AddUint64(&transferred, uint64(n))
	}()

	go func() {
		defer func() { done <- struct{}{} }()
		n, _ := io.Copy(conn, stream)
		c.connMu.Lock()
		c.bytesRecv += uint64(n)
		c.connMu.Unlock()
		atomic.AddUint64(&transferred, uint64(n))
	}()

	<-done

	logrus.WithField("bytes", atomic.LoadUint64(&transferred)).Debug("SOCKS5 connection closed")
}

// Shutdown gracefully shuts down the client.
func (c *Client) Shutdown() {
	logrus.Info("Shutting down client...")

	c.shutdownCancel()

	if c.listener != nil {
		c.listener.Close()
	}

	c.Disconnect()
	c.auth.Close()

	logrus.Info("Client shutdown complete")
}

func main() {
	configPath := "config.json"
	if len(os.Args) > 1 {
		configPath = os.Args[1]
	}

	cfg, err := config.LoadFromFile(configPath)
	if err != nil {
		logrus.Fatalf("Failed to load configuration: %v", err)
	}

	cfg.ConfigureLogger()

	logrus.WithField("config", cfg.String()).Info("Loaded configuration")

	logrus.WithFields(logrus.Fields{
		"go_version": runtime.Version(),
		"os":         runtime.GOOS,
		"arch":       runtime.GOARCH,
		"cpu_count":  runtime.NumCPU(),
	}).Info("System information")

	client := NewClient(cfg)

	sigCh := make(chan os.Signal, 1)
	signal.Notify(sigCh, syscall.SIGINT, syscall.SIGTERM)

	go func() {
		<-sigCh
		client.Shutdown()
		os.Exit(0)
	}()

	if err := client.Run(); err != nil {
		logrus.Fatalf("Client error: %v", err)
	}
}
