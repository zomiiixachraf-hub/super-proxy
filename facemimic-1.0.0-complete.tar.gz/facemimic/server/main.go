// Package main implements the FaceMimic server component.
// The server operates as a dual-port service with exact Facebook-like behavior:
//   - Port 80: Decoy HTTP server with Facebook-identical responses
//   - Port 443: TLS tunnel endpoint with active probe defense
package main

import (
	"bufio"
	"context"
	"crypto/rand"
	"crypto/tls"
	"encoding/binary"
	"fmt"
	"io"
	"math/big"
	"net"
	"net/http"
	"os"
	"os/signal"
	"runtime"
	"syscall"
	"time"

	"github.com/facemimic/core/config"
	"github.com/facemimic/core/core"
	"github.com/sirupsen/logrus"
	"github.com/xtaci/smux"
)

// Server holds the state for the FaceMimic server.
type Server struct {
	config         *config.Config
	auth           *core.Authenticator
	cert           tls.Certificate
	targetAddr     net.IP
	cachedTargetIP net.IP // Cached IP for fallback
	httpsServer    net.Listener
	httpServer     *http.Server
	shutdownCtx    context.Context
	shutdownCancel context.CancelFunc

	// Facebook profile
	profile *core.FacebookProfile
}

// NewServer creates a new FaceMimic server instance.
func NewServer(cfg *config.Config) (*Server, error) {
	cert, err := tls.LoadX509KeyPair(cfg.CertFile, cfg.KeyFile)
	if err != nil {
		return nil, fmt.Errorf("failed to load certificate: %w", err)
	}

	auth := core.NewAuthenticator(cfg.Password, cfg.ReplayCacheSize)

	ctx, cancel := context.WithCancel(context.Background())

	// Cache target IP at startup (critical for zero-latency fallback)
	cachedIP := cfg.TargetAddr

	return &Server{
		config:         cfg,
		auth:           auth,
		cert:           cert,
		targetAddr:     cfg.TargetAddr,
		cachedTargetIP: cachedIP,
		shutdownCtx:    ctx,
		shutdownCancel: cancel,
		profile:        core.DefaultFacebookProfile(),
	}, nil
}

// Start begins listening on both ports.
func (s *Server) Start() error {
	go s.startHTTPDecoy()
	return s.startHTTPSTunnel()
}

// startHTTPDecoy starts the HTTP server on port 80 with Facebook-identical responses.
func (s *Server) startHTTPDecoy() {
	mux := http.NewServeMux()

	// Handler mimicking Facebook's exact HTTP behavior
	mux.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		// Facebook headers exactly
		headers := core.GetFacebookServerHeader()
		for k, v := range headers {
			w.Header().Set(k, v)
		}

		// Redirect to HTTPS with Facebook-style headers
		location := fmt.Sprintf("https://%s%s", s.config.TargetDomain, r.URL.Path)
		if r.URL.RawQuery != "" {
			location += "?" + r.URL.RawQuery
		}
		w.Header().Set("Location", location)

		w.WriteHeader(http.StatusMovedPermanently)

		// Facebook-style HTML body
		fmt.Fprintf(w, `<!DOCTYPE html>
<html lang="en" id="facebook">
<head><title>Redirecting...</title></head>
<body>
<script nonce="">window.location.href="https://%s%s";</script>
</body>
</html>`, s.config.TargetDomain, r.URL.Path)
	})

	// Health check endpoint (for load balancers)
	mux.HandleFunc("/health", func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(http.StatusOK)
		w.Write([]byte("OK"))
	})

	s.httpServer = &http.Server{
		Addr:         ":80",
		Handler:      mux,
		ReadTimeout:  10 * time.Second,
		WriteTimeout: 10 * time.Second,
		IdleTimeout:  60 * time.Second,
	}

	logrus.Info("Starting HTTP decoy server on :80 (Facebook mimic)")
	if err := s.httpServer.ListenAndServe(); err != nil && err != http.ErrServerClosed {
		logrus.WithError(err).Error("HTTP decoy server error")
	}
}

// startHTTPSTunnel starts the HTTPS tunnel server on port 443.
func (s *Server) startHTTPSTunnel() error {
	listener, err := net.Listen("tcp", ":443")
	if err != nil {
		return fmt.Errorf("failed to listen on :443: %w", err)
	}
	s.httpsServer = listener

	logrus.Info("Starting HTTPS tunnel server on :443")

	for {
		select {
		case <-s.shutdownCtx.Done():
			return nil
		default:
			conn, err := listener.Accept()
			if err != nil {
				if s.shutdownCtx.Err() != nil {
					return nil
				}
				logrus.WithError(err).Error("Failed to accept connection")
				continue
			}

			go s.handleConnection(conn)
		}
	}
}

// handleConnection processes a single incoming connection.
func (s *Server) handleConnection(conn net.Conn) {
	defer func() {
		if r := recover(); r != nil {
			logrus.WithField("panic", r).Error("Recovered from panic")
		}
		conn.Close()
	}()

	// Set initial deadline
	conn.SetReadDeadline(time.Now().Add(s.config.HandshakeTimeout))

	// Create buffered reader
	reader := bufio.NewReaderSize(conn, 8192)

	// Peek for TLS record header
	header, err := reader.Peek(5)
	if err != nil {
		logrus.WithError(err).Debug("Failed to peek connection header")
		return
	}

	// Check for TLS handshake (0x16 0x03 xx)
	if header[0] != 0x16 || header[1] != 0x03 {
		// Not TLS - simulate silent timeout (don't send RST)
		logrus.Debug("Non-TLS connection, simulating timeout")
		randomDelay(500, 2000)
		return
	}

	// Peek more bytes for ClientHello analysis
	clientHello, err := reader.Peek(8192)
	if err != nil && err != io.EOF {
		logrus.WithError(err).Debug("Failed to peek ClientHello")
		return
	}

	// Extract SessionID from ClientHello
	sessionID := core.ExtractSessionIDFromClientHello(clientHello)
	if sessionID == nil {
		logrus.Debug("No valid SessionID - treating as probe")
		s.handleProbe(conn, reader)
		return
	}

	// Validate SessionID with time drift tolerance
	valid, timestamp, drift := s.auth.AuthenticateWithDrift(sessionID)
	if !valid {
		logrus.WithField("session_id", fmt.Sprintf("%x", sessionID[:8])).
			Debug("Invalid SessionID - treating as probe")
		s.handleProbe(conn, reader)
		return
	}

	logrus.WithFields(logrus.Fields{
		"timestamp":     timestamp,
		"drift_seconds": drift,
		"remote_addr":   conn.RemoteAddr().String(),
	}).Info("Authenticated connection")

	conn.SetReadDeadline(time.Time{})
	s.handleTunnel(conn, reader)
}

// handleProbe handles potential probe connections by proxying to real Facebook.
func (s *Server) handleProbe(conn net.Conn, reader *bufio.Reader) {
	// Add realistic jitter to mask processing
	randomDelay(10, 50)

	// Connect to real Facebook server using cached IP
	targetAddr := fmt.Sprintf("%s:443", s.cachedTargetIP.String())
	targetConn, err := net.DialTimeout("tcp", targetAddr, 5*time.Second)
	if err != nil {
		logrus.WithError(err).Debug("Failed to connect to target for probe fallback")
		return
	}
	defer targetConn.Close()

	// Get buffered data
	peeked, err := reader.Peek(reader.Buffered())
	if err != nil {
		return
	}

	// Forward buffered data
	if len(peeked) > 0 {
		if _, err := targetConn.Write(peeked); err != nil {
			return
		}
	}

	conn.SetDeadline(time.Time{})

	// Bidirectional proxy with realistic timing
	done := make(chan struct{}, 2)

	go func() {
		defer func() { done <- struct{}{} }()
		io.Copy(targetConn, conn)
	}()

	go func() {
		defer func() { done <- struct{}{} }()
		io.Copy(conn, targetConn)
	}()

	<-done
}

// handleTunnel handles an authenticated tunnel connection.
func (s *Server) handleTunnel(conn net.Conn, reader *bufio.Reader) {
	peeked, err := reader.Peek(reader.Buffered())
	if err != nil {
		logrus.WithError(err).Error("Failed to get buffered data")
		return
	}

	connWrapper := &bufferedConn{
		Conn:   conn,
		reader: reader,
		peeked: peeked,
	}

	// TLS handshake with Chrome-compatible settings
	tlsConfig := &tls.Config{
		Certificates: []tls.Certificate{s.cert},
		MinVersion:   tls.VersionTLS12,
		MaxVersion:   tls.VersionTLS13,
		NextProtos:   []string{"h2", "http/1.1"},
		CipherSuites: []uint16{
			tls.TLS_AES_128_GCM_SHA256,
			tls.TLS_AES_256_GCM_SHA384,
			tls.TLS_CHACHA20_POLY1305_SHA256,
			tls.TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256,
			tls.TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384,
			tls.TLS_ECDHE_RSA_WITH_CHACHA20_POLY1305_SHA256,
		},
	}

	tlsConn := tls.Server(connWrapper, tlsConfig)
	if err := tlsConn.Handshake(); err != nil {
		logrus.WithError(err).Error("TLS handshake failed")
		return
	}
	defer tlsConn.Close()

	state := tlsConn.ConnectionState()
	logrus.WithFields(logrus.Fields{
		"version": state.Version,
		"cipher":  state.CipherSuite,
		"alpn":    state.NegotiatedProtocol,
	}).Debug("TLS handshake completed")

	// Create HTTP/2 layer
	h2Config := core.DefaultH2Config()
	h2Config.Profile = s.profile
	h2Conn := core.NewH2Conn(tlsConn, h2Config)

	ctx, cancel := context.WithCancel(s.shutdownCtx)
	defer cancel()

	h2Conn.StartHeartbeat(ctx, s.config.HeartbeatMinInterval, s.config.HeartbeatMaxInterval)

	// Send Chrome-exact HTTP/2 settings
	if err := core.WriteChromeSettings(h2Conn); err != nil {
		logrus.WithError(err).Error("Failed to write initial settings")
		return
	}

	// Create multiplexing session
	muxConfig := smux.DefaultConfig()
	muxConfig.MaxReceiveBuffer = 4194304
	muxConfig.MaxStreamBuffer = 2097152

	muxSession, err := smux.Server(h2Conn, muxConfig)
	if err != nil {
		logrus.WithError(err).Error("Failed to create mux server")
		return
	}
	defer muxSession.Close()

	logrus.Info("Tunnel established, accepting streams")

	for {
		stream, err := muxSession.AcceptStream()
		if err != nil {
			logrus.WithError(err).Debug("Failed to accept stream")
			return
		}

		go s.handleStream(stream)
	}
}

// handleStream handles a single multiplexed stream.
func (s *Server) handleStream(stream *smux.Stream) {
	defer stream.Close()

	addrBuf := make([]byte, 6)
	if _, err := io.ReadFull(stream, addrBuf); err != nil {
		logrus.WithError(err).Debug("Failed to read destination address")
		return
	}

	destIP := net.IP(addrBuf[:4])
	destPort := int(addrBuf[4])<<8 | int(addrBuf[5])
	destAddr := fmt.Sprintf("%s:%d", destIP.String(), destPort)

	logrus.WithField("dest", destAddr).Debug("Opening downstream connection")

	destConn, err := net.DialTimeout("tcp", destAddr, 10*time.Second)
	if err != nil {
		logrus.WithError(err).WithField("dest", destAddr).Debug("Failed to connect to destination")
		return
	}
	defer destConn.Close()

	done := make(chan struct{}, 2)

	go func() {
		defer func() { done <- struct{}{} }()
		io.Copy(destConn, stream)
	}()

	go func() {
		defer func() { done <- struct{}{} }()
		io.Copy(stream, destConn)
	}()

	<-done
}

// bufferedConn wraps net.Conn with buffered reader support.
type bufferedConn struct {
	net.Conn
	reader *bufio.Reader
	peeked []byte
	read   int
}

func (bc *bufferedConn) Read(p []byte) (int, error) {
	if bc.read < len(bc.peeked) {
		n := copy(p, bc.peeked[bc.read:])
		bc.read += n
		return n, nil
	}
	return bc.reader.Read(p)
}

// randomDelay adds a random delay to simulate realistic timing.
func randomDelay(minMs, maxMs int) {
	n, _ := rand.Int(rand.Reader, big.NewInt(int64(maxMs-minMs)))
	delay := time.Duration(minMs+int(n.Int64())) * time.Millisecond
	time.Sleep(delay)
}

// Shutdown gracefully shuts down the server.
func (s *Server) Shutdown() {
	logrus.Info("Shutting down server...")

	s.shutdownCancel()

	if s.httpServer != nil {
		ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
		defer cancel()
		s.httpServer.Shutdown(ctx)
	}

	if s.httpsServer != nil {
		s.httpsServer.Close()
	}

	s.auth.Close()

	logrus.Info("Server shutdown complete")
}

func main() {
	configPath := "config.json"
	if len(os.Args) > 1 {
		configPath = os.Args[1]
	}

	cfg, err := config.LoadFromFile(configPath)
	if err != nil {
		logrus.Fatalf("Failed to load configuration: %v", err)
	}

	cfg.ConfigureLogger()

	logrus.WithField("config", cfg.String()).Info("Loaded configuration")

	logrus.WithFields(logrus.Fields{
		"go_version": runtime.Version(),
		"os":         runtime.GOOS,
		"arch":       runtime.GOARCH,
		"goroutines": runtime.NumGoroutine(),
		"cpu_count":  runtime.NumCPU(),
	}).Info("System information")

	server, err := NewServer(cfg)
	if err != nil {
		logrus.Fatalf("Failed to create server: %v", err)
	}

	sigCh := make(chan os.Signal, 1)
	signal.Notify(sigCh, syscall.SIGINT, syscall.SIGTERM)

	go func() {
		<-sigCh
		server.Shutdown()
		os.Exit(0)
	}()

	if err := server.Start(); err != nil {
		logrus.Fatalf("Server error: %v", err)
	}
}
