#!/bin/bash
#
# FaceMimic Management CLI
# Easy-to-use command line tool for server management
#

set -e

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m'

INSTALL_DIR="/opt/facemimic"
CONFIG_FILE="$INSTALL_DIR/config.json"

# Show menu
show_menu() {
    clear
    echo -e "${CYAN}"
    echo "╔═══════════════════════════════════════════════════════════════╗"
    echo "║                    FaceMimic Manager v1.0                     ║"
    echo "╠═══════════════════════════════════════════════════════════════╣"
    echo "║                                                               ║"
    echo -e "║  ${GREEN}1.${NC} 📊 عرض الحالة                                           ║"
    echo -e "║  ${GREEN}2.${NC} 📱 عرض معلومات الاتصال                                   ║"
    echo -e "║  ${GREEN}3.${NC} 🔑 تغيير كلمة المرور                                     ║"
    echo -e "║  ${GREEN}4.${NC} 🔄 إعادة تشغيل الخدمة                                    ║"
    echo -e "║  ${GREEN}5.${NC} 📋 عرض السجلات                                          ║"
    echo -e "║  ${GREEN}6.${NC} 📥 تصدير ملفات التكوين                                   ║"
    echo -e "║  ${GREEN}7.${NC} 🌐 فتح لوحة التحكم                                       ║"
    echo -e "║  ${GREEN}8.${NC} 🔄 تحديث البرنامج                                        ║"
    echo -e "║  ${GREEN}9.${NC} 🗑️  إلغاء التثبيت                                        ║"
    echo -e "║  ${GREEN}0.${NC} 🚪 خروج                                                  ║"
    echo "║                                                               ║"
    echo "╚═══════════════════════════════════════════════════════════════╝"
    echo -e "${NC}"
}

# Get server IP
get_ip() {
    curl -s ifconfig.me 2>/dev/null || curl -s ip.sb 2>/dev/null || echo "Unknown"
}

# Get password
get_password() {
    grep -o '"password": "[^"]*"' "$CONFIG_FILE" 2>/dev/null | cut -d'"' -f4 || echo "Not found"
}

# Show status
show_status() {
    echo -e "\n${CYAN}📊 حالة الخدمة:${NC}"
    
    if systemctl is-active --quiet facemimic; then
        echo -e "  الحالة: ${GREEN}يعمل ✓${NC}"
    else
        echo -e "  الحالة: ${RED}متوقف ✗${NC}"
    fi
    
    echo ""
    echo -e "${CYAN}📈 إحصائيات:${NC}"
    
    # Get uptime
    UPTIME=$(systemctl show facemimic --property=ActiveEnterTimestamp 2>/dev/null | cut -d= -f2)
    if [ -n "$UPTIME" ]; then
        echo -e "  بدء التشغيل: $UPTIME"
    fi
    
    # Get memory usage
    MEM=$(ps aux | grep kworker-d | grep -v grep | awk '{print $6}' 2>/dev/null)
    if [ -n "$MEM" ]; then
        echo -e "  الذاكرة: $((MEM/1024)) MB"
    fi
    
    echo ""
    read -p "اضغط Enter للمتابعة..."
}

# Show connection info
show_connection_info() {
    IP=$(get_ip)
    PASS=$(get_password)
    
    echo -e "\n${CYAN}📱 معلومات الاتصال:${NC}\n"
    echo -e "  ${YELLOW}Server IP:${NC}     $IP"
    echo -e "  ${YELLOW}Port:${NC}         443"
    echo -e "  ${YELLOW}Password:${NC}     $PASS"
    
    echo -e "\n${CYAN}🔗 رابط الاتصال:${NC}\n"
    echo -e "  facemimic://$IP:443?password=$PASS"
    
    echo -e "\n${CYAN}📲 إعداد الهاتف:${NC}\n"
    echo "  1. حمل تطبيق Clash أو SingBox"
    echo "  2. استورد ملف التكوين من:"
    echo -e "     ${YELLOW}$INSTALL_DIR/client-configs/${NC}"
    echo "  3. أو امسح الكود QR من:"
    echo -e "     ${YELLOW}http://$IP:8080${NC}"
    
    echo ""
    read -p "اضغط Enter للمتابعة..."
}

# Change password
change_password() {
    echo -e "\n${CYAN}🔑 تغيير كلمة المرور:${NC}\n"
    
    # Generate new password
    NEW_PASS=$(openssl rand -base64 32 | tr -d '/+=' | head -c 32)
    
    echo -e "  كلمة المرور الجديدة: ${YELLOW}$NEW_PASS${NC}"
    echo ""
    read -p "هل تريد استخدام هذه الكلمة؟ (y/n): " -n 1 -r
    echo ""
    
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        read -p "أدخل كلمة المرور الجديدة: " NEW_PASS
    fi
    
    # Update config
    sed -i "s/\"password\": \"[^\"]*\"/\"password\": \"$NEW_PASS\"/" "$CONFIG_FILE"
    
    # Update client configs
    generate_client_configs
    
    # Restart service
    systemctl restart facemimic
    
    echo -e "\n${GREEN}✓ تم تغيير كلمة المرور بنجاح${NC}"
    echo -e "  كلمة المرور الجديدة: ${YELLOW}$NEW_PASS${NC}"
    echo ""
    read -p "اضغط Enter للمتابعة..."
}

# Generate client configs
generate_client_configs() {
    IP=$(get_ip)
    PASS=$(get_password)
    
    mkdir -p "$INSTALL_DIR/client-configs"
    
    # Connection URL
    echo "facemimic://$IP:443?password=$PASS" > "$INSTALL_DIR/client-configs/connection-url.txt"
    
    # Client config
    cat > "$INSTALL_DIR/client-configs/client.json" << EOF
{
    "server_ip": "$IP",
    "listen_port": 1080,
    "target_domain": "www.facebook.com",
    "password": "$PASS",
    "connection_timeout": "10s",
    "handshake_timeout": "5s",
    "max_connection_duration": "30m",
    "max_throughput_bytes": 524288000,
    "heartbeat_min_interval": "15s",
    "heartbeat_max_interval": "45s",
    "replay_cache_size": 10000,
    "log_level": "info"
}
EOF
    
    # Clash config
    cat > "$INSTALL_DIR/client-configs/clash.yaml" << EOF
port: 7890
socks-port: 7891
allow-lan: true
mode: Rule

proxies:
  - name: "FaceMimic"
    type: socks5
    server: 127.0.0.1
    port: 1080

proxy-groups:
  - name: "Proxy"
    type: select
    proxies:
      - FaceMimic
      - DIRECT

rules:
  - MATCH,Proxy
EOF
}

# Restart service
restart_service() {
    echo -e "\n${CYAN}🔄 إعادة تشغيل الخدمة...${NC}"
    systemctl restart facemimic
    sleep 2
    
    if systemctl is-active --quiet facemimic; then
        echo -e "${GREEN}✓ تم إعادة التشغيل بنجاح${NC}"
    else
        echo -e "${RED}✗ فشل إعادة التشغيل${NC}"
    fi
    
    echo ""
    read -p "اضغط Enter للمتابعة..."
}

# Show logs
show_logs() {
    echo -e "\n${CYAN}📋 السجلات (اضغط Ctrl+C للخروج):${NC}\n"
    journalctl -u facemimic -f --no-pager
}

# Export configs
export_configs() {
    echo -e "\n${CYAN}📥 تصدير ملفات التكوين:${NC}\n"
    
    EXPORT_DIR="$HOME/facemimic-export"
    mkdir -p "$EXPORT_DIR"
    
    cp -r "$INSTALL_DIR/client-configs/"* "$EXPORT_DIR/"
    
    echo -e "${GREEN}✓ تم التصدير إلى:${NC}"
    echo -e "  ${YELLOW}$EXPORT_DIR${NC}"
    
    # Show files
    echo -e "\n${CYAN}الملفات:${NC}"
    ls -la "$EXPORT_DIR"
    
    echo ""
    read -p "اضغط Enter للمتابعة..."
}

# Open dashboard
open_dashboard() {
    IP=$(get_ip)
    echo -e "\n${CYAN}🌐 لوحة التحكم:${NC}\n"
    echo -e "  افتح في المتصفح: ${YELLOW}http://$IP:8080${NC}"
    echo ""
    
    # Check if dashboard is running
    if command -v xdg-open &> /dev/null; then
        read -p "هل تريد فتحها الآن؟ (y/n): " -n 1 -r
        echo ""
        if [[ $REPLY =~ ^[Yy]$ ]]; then
            xdg-open "http://$IP:8080" 2>/dev/null &
        fi
    fi
    
    echo ""
    read -p "اضغط Enter للمتابعة..."
}

# Update
update_facemimic() {
    echo -e "\n${CYAN}🔄 تحديث FaceMimic...${NC}\n"
    
    # Backup config
    cp "$CONFIG_FILE" "$CONFIG_FILE.backup"
    
    # Download latest version (you should implement this)
    echo "جاري التحقق من التحديثات..."
    
    # For now, just rebuild
    echo -e "${YELLOW}ملاحظة: قم بتحميل أحدث إصدار يدوياً${NC}"
    
    echo ""
    read -p "اضغط Enter للمتابعة..."
}

# Uninstall
uninstall() {
    echo -e "\n${RED}⚠️  تحذير: سيتم حذف FaceMimic بالكامل!${NC}\n"
    read -p "هل أنت متأكد؟ (yes/no): " -r
    
    if [ "$REPLY" = "yes" ]; then
        echo -e "\n${CYAN}جاري إلغاء التثبيت...${NC}"
        
        systemctl stop facemimic 2>/dev/null || true
        systemctl disable facemimic 2>/dev/null || true
        rm -f /etc/systemd/system/facemimic.service
        systemctl daemon-reload
        rm -rf "$INSTALL_DIR"
        
        echo -e "${GREEN}✓ تم إلغاء التثبيت${NC}"
    else
        echo -e "${YELLOW}تم الإلغاء${NC}"
    fi
    
    echo ""
    read -p "اضغط Enter للمتابعة..."
}

# Main loop
main() {
    while true; do
        show_menu
        read -p "اختر رقم: " choice
        
        case $choice in
            1) show_status ;;
            2) show_connection_info ;;
            3) change_password ;;
            4) restart_service ;;
            5) show_logs ;;
            6) export_configs ;;
            7) open_dashboard ;;
            8) update_facemimic ;;
            9) uninstall ;;
            0) echo -e "\n${GREEN}مع السلامة! 👋${NC}\n"; exit 0 ;;
            *) echo -e "\n${RED}خيار غير صحيح${NC}" ;;
        esac
    done
}

# Quick commands
if [ "$1" = "status" ]; then
    systemctl status facemimic --no-pager
elif [ "$1" = "info" ]; then
    show_connection_info
elif [ "$1" = "restart" ]; then
    systemctl restart facemimic
    echo "Restarted"
elif [ "$1" = "logs" ]; then
    journalctl -u facemimic -f
elif [ "$1" = "password" ]; then
    change_password
else
    main
fi
